import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Map } from '@/components/ui/map';
import { EmergencyService, Story } from '@shared/schema';
import { format } from 'date-fns';

export default function Destination() {
  const { id } = useParams<{ id: string }>();
  const destinationId = parseInt(id);

  // Fetch destination details
  const { data: destination, isLoading: destinationLoading } = useQuery({
    queryKey: [`/api/destinations/${destinationId}`],
    enabled: Boolean(destinationId),
  });

  // Fetch stories for this location
  const { data: stories, isLoading: storiesLoading } = useQuery({
    queryKey: [`/api/stories/country/${destination?.country}`],
    enabled: Boolean(destination?.country),
  });

  // Fetch emergency services for this location
  const { data: emergencyServices, isLoading: servicesLoading } = useQuery({
    queryKey: [`/api/emergency-services/${destination?.country}`],
    enabled: Boolean(destination?.country),
  });

  // Fetch safety alerts for this location
  const { data: safetyAlerts, isLoading: alertsLoading } = useQuery({
    queryKey: [`/api/safety-alerts/location/${destination?.name}`],
    enabled: Boolean(destination?.name),
  });

  if (destinationLoading || !destination) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center h-[60vh]">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <span className="ml-3">Loading destination details...</span>
        </div>
      </div>
    );
  }

  // Get safety score color
  const getSafetyScoreColor = (score: number) => {
    if (score >= 4.5) return "text-[#34A853]";
    if (score >= 4.0) return "text-blue-500";
    if (score >= 3.5) return "text-yellow-500";
    return "text-[#EA4335]";
  };

  // Get safety status badge class
  const getSafetyStatusClass = (status: string) => {
    if (status.includes("Very Safe") || status.includes("Safe for")) {
      return "bg-green-100 text-[#34A853]";
    } else if (status.includes("Generally Safe")) {
      return "bg-blue-100 text-blue-700";
    } else if (status.includes("Moderate Caution")) {
      return "bg-yellow-100 text-yellow-800";
    } else {
      return "bg-red-100 text-red-700";
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-4">
        <Link href="/#destinations">
          <a className="text-primary hover:underline inline-flex items-center">
            <i className="fas fa-arrow-left mr-2"></i> Back to Destinations
          </a>
        </Link>
      </div>
      
      {/* Hero Section */}
      <div className="relative h-64 md:h-96 rounded-xl overflow-hidden mb-8">
        <img 
          src={destination.imageUrl} 
          alt={`${destination.name} cityscape`} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-60"></div>
        <div className="absolute bottom-0 left-0 p-6 md:p-8 text-white">
          <div className="flex items-center mb-2">
            <div className={`${getSafetyStatusClass(destination.safetyStatus)} rounded-full px-3 py-1 text-sm font-medium text-white bg-opacity-90 mr-3`}>
              <i className="fas fa-shield-alt mr-1"></i> {destination.safetyStatus}
            </div>
            <div className="bg-white bg-opacity-90 rounded-full px-3 py-1 text-sm font-semibold flex items-center">
              <i className={`fas fa-star ${getSafetyScoreColor(destination.safetyScore)} mr-1`}></i>
              <span className="text-neutral-800">{destination.safetyScore}/5 Safety Score</span>
            </div>
          </div>
          <h1 className="font-heading font-bold text-3xl md:text-4xl">{destination.name}, {destination.country}</h1>
          <p className="text-white text-opacity-90 max-w-xl mt-2">{destination.description}</p>
        </div>
      </div>
      
      {/* Active Travelers */}
      <div className="bg-white rounded-xl shadow-md p-4 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-heading font-semibold text-xl mb-1">
              <i className="fas fa-users text-primary mr-2"></i> Active Travelers
            </h2>
            <p className="text-neutral-600">
              Connect with <span className="font-semibold">{destination.activeTravelers}</span> fellow travelers currently in {destination.name}
            </p>
          </div>
          <Link href="/#chat">
            <Button className="bg-primary text-white font-medium py-2 px-4 rounded-lg">
              <i className="fas fa-comments mr-2"></i> Chat with Travelers
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Tabs Section */}
      <Tabs defaultValue="safety-map" className="mb-8">
        <TabsList className="bg-white rounded-lg p-1 border border-neutral-200 mb-4">
          <TabsTrigger value="safety-map" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <i className="fas fa-map-marked-alt mr-2"></i> Safety Map
          </TabsTrigger>
          <TabsTrigger value="emergency" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <i className="fas fa-ambulance mr-2"></i> Emergency Services
          </TabsTrigger>
          <TabsTrigger value="stories" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <i className="fas fa-exclamation-triangle mr-2"></i> Theft Stories
          </TabsTrigger>
          <TabsTrigger value="tips" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <i className="fas fa-lightbulb mr-2"></i> Safety Tips
          </TabsTrigger>
        </TabsList>
        
        {/* Safety Map Tab */}
        <TabsContent value="safety-map" className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-4 border-b border-neutral-200">
            <h2 className="font-heading font-semibold text-xl">Safety Map for {destination.name}</h2>
            <p className="text-neutral-600">Explore safe areas, emergency services, and potential hazards.</p>
          </div>
          <div className="h-[500px] relative">
            <Map 
              height="100%" 
              width="100%" 
              markers={[
                { id: "hospital1", lat: 0, lng: 0, title: "Central Hospital", type: "hospital" },
                { id: "police1", lat: 0, lng: 0, title: "Police Station", type: "police" },
                { id: "embassy1", lat: 0, lng: 0, title: "Embassy", type: "embassy" },
                { id: "alert1", lat: 0, lng: 0, title: "Theft Alert", type: "alert" }
              ]}
            />
            
            {/* Safety Alerts Overlay */}
            <div className="absolute top-4 right-4 bg-white rounded-lg shadow-md p-3 max-w-xs">
              <h3 className="font-medium text-neutral-800 mb-2 flex items-center">
                <i className="fas fa-bell text-[#EA4335] mr-2"></i> Active Alerts
              </h3>
              <div className="max-h-40 overflow-y-auto">
                {alertsLoading ? (
                  <p className="text-sm text-neutral-500">Loading alerts...</p>
                ) : safetyAlerts && safetyAlerts.length > 0 ? (
                  safetyAlerts.map((alert: any) => (
                    <div key={alert.id} className="bg-red-50 border-l-4 border-[#EA4335] p-2 rounded-r mb-2 text-sm">
                      <div className="font-medium text-[#EA4335]">{alert.title}</div>
                      <p className="text-neutral-700">{alert.content}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-neutral-500">No active alerts for this location</p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* Emergency Services Tab */}
        <TabsContent value="emergency" className="bg-white rounded-xl shadow-md p-4">
          <h2 className="font-heading font-semibold text-xl mb-4">Emergency Services in {destination.name}</h2>
          
          {servicesLoading ? (
            <div className="text-center p-4">
              <div className="inline-block h-6 w-6 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <p className="mt-2 text-neutral-600">Loading emergency services...</p>
            </div>
          ) : emergencyServices && emergencyServices.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {emergencyServices.map((service: EmergencyService) => (
                <Card key={service.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className={`p-3 text-white ${service.serviceType === 'Hospital' ? 'bg-[#34A853]' : service.serviceType === 'Police' ? 'bg-primary' : 'bg-purple-600'}`}>
                      <div className="flex items-center">
                        <div className="rounded-full bg-white bg-opacity-20 p-2 mr-3">
                          <i className={`fas ${service.serviceType === 'Hospital' ? 'fa-hospital' : service.serviceType === 'Police' ? 'fa-shield-alt' : 'fa-flag'} text-lg`}></i>
                        </div>
                        <div>
                          <h3 className="font-medium">{service.name}</h3>
                          <p className="text-sm text-white text-opacity-90">{service.serviceType}</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="text-sm text-neutral-700 mb-2">
                        <i className="fas fa-map-marker-alt text-neutral-500 mr-2"></i> {service.address}
                      </p>
                      <p className="text-sm text-neutral-700 mb-3">
                        <i className="fas fa-phone-alt text-neutral-500 mr-2"></i> {service.phone}
                      </p>
                      <a href={`tel:${service.phone.replace(/\s/g, '')}`} className="block text-center bg-neutral-100 text-neutral-700 py-2 rounded-lg text-sm hover:bg-neutral-200 transition-colors">
                        <i className="fas fa-phone mr-2"></i> Call
                      </a>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center p-8 bg-neutral-50 rounded-lg">
              <div className="text-5xl text-neutral-300 mb-3">
                <i className="fas fa-info-circle"></i>
              </div>
              <h3 className="text-lg font-medium text-neutral-700 mb-2">No Emergency Services Data</h3>
              <p className="text-neutral-600">
                We don't have emergency service information for this location yet. For emergencies, dial the international emergency number 112.
              </p>
            </div>
          )}
          
          {/* Emergency Numbers Card */}
          <div className="mt-6 bg-neutral-100 p-4 rounded-lg">
            <h3 className="font-medium text-lg mb-2">Common Emergency Numbers</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="flex items-center mb-1">
                  <div className="bg-red-100 text-red-600 p-2 rounded-full mr-3">
                    <i className="fas fa-ambulance"></i>
                  </div>
                  <div>
                    <p className="font-medium">Ambulance</p>
                    <p className="text-2xl font-bold">112</p>
                  </div>
                </div>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="flex items-center mb-1">
                  <div className="bg-blue-100 text-blue-600 p-2 rounded-full mr-3">
                    <i className="fas fa-shield-alt"></i>
                  </div>
                  <div>
                    <p className="font-medium">Police</p>
                    <p className="text-2xl font-bold">112</p>
                  </div>
                </div>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <div className="flex items-center mb-1">
                  <div className="bg-orange-100 text-orange-600 p-2 rounded-full mr-3">
                    <i className="fas fa-fire-extinguisher"></i>
                  </div>
                  <div>
                    <p className="font-medium">Fire</p>
                    <p className="text-2xl font-bold">112</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* Theft Stories Tab */}
        <TabsContent value="stories" className="bg-white rounded-xl shadow-md p-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-heading font-semibold text-xl">Theft Stories in {destination.name}</h2>
            <Link href="/share-story">
              <Button className="bg-primary text-white font-medium py-2 px-4 rounded-lg">
                <i className="fas fa-plus mr-2"></i> Share Your Story
              </Button>
            </Link>
          </div>
          
          {storiesLoading ? (
            <div className="text-center p-4">
              <div className="inline-block h-6 w-6 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <p className="mt-2 text-neutral-600">Loading stories...</p>
            </div>
          ) : stories && stories.length > 0 ? (
            <div className="space-y-4">
              {stories.map((story: Story) => (
                <Link key={story.id} href={`/story/${story.id}`}>
                  <div className="bg-neutral-50 hover:bg-neutral-100 transition-colors p-4 rounded-lg cursor-pointer">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-lg">{story.title}</h3>
                      <span className={`text-xs font-medium px-2 py-1 rounded ${
                        story.incidentType === 'Pickpocketing' ? 'bg-yellow-100 text-yellow-800' :
                        story.incidentType === 'Scam' ? 'bg-orange-100 text-orange-800' :
                        story.incidentType === 'Robbery' ? 'bg-red-100 text-red-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {story.incidentType}
                      </span>
                    </div>
                    <div className="text-sm text-neutral-500 mb-2">
                      <i className="far fa-calendar-alt mr-1"></i> {format(new Date(story.incidentDate), 'MMM d, yyyy')}
                      <span className="mx-2">•</span>
                      <i className="fas fa-map-marker-alt mr-1"></i> {story.location}
                    </div>
                    <p className="text-neutral-700 line-clamp-2 mb-2">{story.content}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-6 h-6 rounded-full bg-neutral-300 flex items-center justify-center text-xs mr-2">
                          <i className="fas fa-user"></i>
                        </div>
                        <span className="text-sm text-neutral-600">User {story.userId}</span>
                      </div>
                      <div className="flex space-x-3 text-neutral-500 text-sm">
                        <span><i className="far fa-thumbs-up mr-1"></i> {story.likes}</span>
                        <span><i className="far fa-comment mr-1"></i> {story.comments}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center p-8 bg-neutral-50 rounded-lg">
              <div className="text-5xl text-neutral-300 mb-3">
                <i className="fas fa-book"></i>
              </div>
              <h3 className="text-lg font-medium text-neutral-700 mb-2">No Stories Yet</h3>
              <p className="text-neutral-600 mb-4">
                There are no theft stories for this location yet. Share your experience to help other travelers.
              </p>
              <Link href="/share-story">
                <Button className="bg-primary text-white font-medium py-2 px-4 rounded-lg">
                  <i className="fas fa-plus mr-2"></i> Share Your Story
                </Button>
              </Link>
            </div>
          )}
        </TabsContent>
        
        {/* Safety Tips Tab */}
        <TabsContent value="tips" className="bg-white rounded-xl shadow-md p-4">
          <h2 className="font-heading font-semibold text-xl mb-4">Safety Tips for {destination.name}</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-neutral-50 p-4 rounded-lg">
              <h3 className="font-medium text-lg mb-3 flex items-center">
                <i className="fas fa-walking text-primary mr-2"></i> Out and About
              </h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Avoid displaying expensive jewelry or electronics</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Keep your wallet in your front pocket and bags securely closed</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Stay in well-lit and populated areas, especially at night</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Be cautious with ATMs and cover your PIN when entering</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Stay alert in crowded tourist spots and public transportation</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-neutral-50 p-4 rounded-lg">
              <h3 className="font-medium text-lg mb-3 flex items-center">
                <i className="fas fa-home text-primary mr-2"></i> Accommodations
              </h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Use a safe for valuables and important documents</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Keep your door locked at all times and don't open for strangers</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Check fire escape routes upon arrival</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Share your accommodation details with a trusted contact</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Research the neighborhood's safety before booking</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-neutral-50 p-4 rounded-lg">
              <h3 className="font-medium text-lg mb-3 flex items-center">
                <i className="fas fa-car text-primary mr-2"></i> Transportation
              </h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Use only licensed taxis or reputable ride-share services</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Be cautious of "unofficial" guides or taxi drivers</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Keep your belongings close when on public transport</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Research local transportation scams before your trip</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Have the address of your destination written down in the local language</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-neutral-50 p-4 rounded-lg">
              <h3 className="font-medium text-lg mb-3 flex items-center">
                <i className="fas fa-briefcase-medical text-primary mr-2"></i> Health & Emergency
              </h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Have travel insurance that covers medical emergencies</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Keep a basic first aid kit and any necessary medications</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Know the location of the nearest hospital</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Save local emergency numbers on your phone</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                  <span>Set up the SafeConnect SOS feature before your trip</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-6 p-4 bg-primary bg-opacity-10 rounded-lg">
            <h3 className="font-medium text-lg text-primary mb-2">Local Customs and Laws</h3>
            <p className="text-neutral-700 mb-3">
              Always research and respect local customs, traditions, and laws. What may be acceptable in your home country could be offensive or illegal in {destination.name}.
            </p>
            <p className="text-neutral-700">
              Remember that SafeConnect's theft stories and safety tips are provided by our community of travelers. While we strive for accuracy, always use your own judgment and stay aware of your surroundings.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
