import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useSos } from '@/hooks/use-sos';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Link } from 'wouter';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';

// Form validation schema
const profileFormSchema = z.object({
  fullName: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().optional(),
  nationality: z.string().optional(),
  language: z.string().optional(),
  bio: z.string().max(160).optional(),
  emergencyContacts: z.array(z.string().email({ message: "Please enter a valid email address." })),
  newEmergencyContact: z.string().email().optional(),
  notifyOnSafetyAlert: z.boolean().default(true),
  sosEnabled: z.boolean().default(true),
  locationSharing: z.boolean().default(false),
});

// Mock user data for demo purposes
const demoUser = {
  id: 1,
  username: "traveler123",
  fullName: "Alex Morgan",
  email: "alex@example.com",
  phone: "+1234567890",
  nationality: "United States",
  language: "English",
  bio: "Passionate traveler exploring the world one country at a time. Safety conscious and always up for meeting fellow adventurers!",
  profilePic: "",
  emergencyContacts: ["emergency@example.com", "family@example.com"],
  notifyOnSafetyAlert: true,
  sosEnabled: true,
  locationSharing: false,
};

export default function Profile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("profile");
  const [newEmergencyContact, setNewEmergencyContact] = useState("");
  const { sendSos, isSending: sosIsSending } = useSos({ userId: 1 });

  // Use demo user data for the profile page
  const userData = demoUser;

  // Initialize form with user data
  const form = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      fullName: userData.fullName,
      email: userData.email,
      phone: userData.phone,
      nationality: userData.nationality,
      language: userData.language,
      bio: userData.bio,
      emergencyContacts: userData.emergencyContacts,
      notifyOnSafetyAlert: userData.notifyOnSafetyAlert,
      sosEnabled: userData.sosEnabled,
      locationSharing: userData.locationSharing,
    },
  });

  // Function to handle form submission
  function onSubmit(values: z.infer<typeof profileFormSchema>) {
    // Simulate API call to update profile
    // In a real implementation, this would be an actual API call
    setTimeout(() => {
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    }, 1000);
  }

  // Add emergency contact
  const handleAddEmergencyContact = () => {
    const contact = form.watch("newEmergencyContact");
    if (!contact) return;
    
    // Validate email format
    if (!z.string().email().safeParse(contact).success) {
      form.setError("newEmergencyContact", {
        type: "manual",
        message: "Please enter a valid email address",
      });
      return;
    }
    
    const currentContacts = form.getValues("emergencyContacts") || [];
    if (currentContacts.includes(contact)) {
      form.setError("newEmergencyContact", {
        type: "manual",
        message: "This contact already exists",
      });
      return;
    }
    
    form.setValue("emergencyContacts", [...currentContacts, contact]);
    form.setValue("newEmergencyContact", "");
  };

  // Remove emergency contact
  const handleRemoveEmergencyContact = (contactToRemove: string) => {
    const currentContacts = form.getValues("emergencyContacts") || [];
    form.setValue(
      "emergencyContacts",
      currentContacts.filter(contact => contact !== contactToRemove)
    );
  };

  // Test SOS alert
  const handleTestSOS = async () => {
    try {
      await sendSos();
      toast({
        title: "SOS Test Successful",
        description: "Your emergency contacts would be notified in a real emergency.",
      });
    } catch (error) {
      toast({
        title: "SOS Test Failed",
        description: "Could not send the test SOS alert. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="md:w-1/4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center mb-6">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarFallback className="bg-primary text-2xl text-white">
                    {userData.fullName?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold">{userData.fullName}</h2>
                <p className="text-sm text-neutral-500">{userData.username}</p>
              </div>
              
              <div className="space-y-1">
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === "profile" ? "bg-neutral-100" : ""}`}
                  onClick={() => setActiveTab("profile")}
                >
                  <i className="fas fa-user mr-2"></i> Profile
                </Button>
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === "safety" ? "bg-neutral-100" : ""}`}
                  onClick={() => setActiveTab("safety")}
                >
                  <i className="fas fa-shield-alt mr-2"></i> Safety Settings
                </Button>
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === "trips" ? "bg-neutral-100" : ""}`}
                  onClick={() => setActiveTab("trips")}
                >
                  <i className="fas fa-suitcase mr-2"></i> My Trips
                </Button>
                <Button 
                  variant="ghost" 
                  className={`w-full justify-start ${activeTab === "stories" ? "bg-neutral-100" : ""}`}
                  onClick={() => setActiveTab("stories")}
                >
                  <i className="fas fa-book mr-2"></i> My Stories
                </Button>
              </div>
            </CardContent>
          </Card>
          
          {/* SOS Card */}
          <Card className="mt-4 border-2 border-[#EA4335]">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center">
                <div className="bg-[#EA4335] rounded-full p-4 text-white text-2xl mb-4">
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
                <h3 className="font-bold text-lg mb-2">Emergency SOS</h3>
                <p className="text-sm text-center text-neutral-600 mb-4">
                  In case of emergency, press the SOS button to alert your emergency contacts
                </p>
                <Button 
                  className="w-full bg-[#EA4335] hover:bg-red-700 text-white"
                  onClick={handleTestSOS}
                  disabled={sosIsSending}
                >
                  {sosIsSending ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
                      Sending...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-exclamation-circle mr-2"></i> 
                      Test SOS Alert
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Content */}
        <div className="md:w-3/4">
          {/* Profile Tab */}
          {activeTab === "profile" && (
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>
                  Update your personal information and preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="Your email address" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="nationality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nationality</FormLabel>
                            <FormControl>
                              <Input placeholder="Your nationality" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="language"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Language</FormLabel>
                            <FormControl>
                              <Input placeholder="Your preferred language" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell other travelers a bit about yourself" 
                              className="resize-none" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Maximum 160 characters
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end">
                      <Button type="submit" className="bg-primary text-white">
                        Save Changes
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {/* Safety Settings Tab */}
          {activeTab === "safety" && (
            <Card>
              <CardHeader>
                <CardTitle>Safety Settings</CardTitle>
                <CardDescription>
                  Configure your safety preferences and emergency contacts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="border rounded-md p-4 space-y-4">
                      <h3 className="font-medium text-lg">Emergency Contacts</h3>
                      <p className="text-sm text-neutral-500">
                        These contacts will be notified when you activate the SOS feature
                      </p>
                      
                      <div className="flex gap-2">
                        <FormField
                          control={form.control}
                          name="newEmergencyContact"
                          render={({ field }) => (
                            <FormItem className="flex-1">
                              <FormControl>
                                <Input 
                                  placeholder="Enter email address" 
                                  {...field} 
                                  onChange={(e) => {
                                    field.onChange(e);
                                    setNewEmergencyContact(e.target.value);
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="button" 
                          onClick={handleAddEmergencyContact}
                          disabled={!form.watch("newEmergencyContact")}
                        >
                          Add Contact
                        </Button>
                      </div>
                      
                      <div className="space-y-2">
                        {form.watch("emergencyContacts")?.map((contact, index) => (
                          <div key={index} className="flex justify-between items-center bg-neutral-50 p-3 rounded-md">
                            <div className="flex items-center">
                              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white mr-3">
                                <i className="fas fa-user"></i>
                              </div>
                              <span>{contact}</span>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleRemoveEmergencyContact(contact)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <i className="fas fa-trash"></i>
                            </Button>
                          </div>
                        ))}
                        
                        {(!form.watch("emergencyContacts") || form.watch("emergencyContacts").length === 0) && (
                          <div className="text-center py-4 text-neutral-500">
                            <p>No emergency contacts added yet</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="border rounded-md p-4 space-y-4">
                      <h3 className="font-medium text-lg">Safety Preferences</h3>
                      
                      <FormField
                        control={form.control}
                        name="sosEnabled"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between p-3 rounded-md bg-neutral-50">
                            <div>
                              <FormLabel className="font-medium">SOS Feature</FormLabel>
                              <FormDescription>Enable the SOS emergency alert feature</FormDescription>
                            </div>
                            <FormControl>
                              <Switch 
                                checked={field.value} 
                                onCheckedChange={field.onChange} 
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="notifyOnSafetyAlert"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between p-3 rounded-md bg-neutral-50">
                            <div>
                              <FormLabel className="font-medium">Safety Alerts</FormLabel>
                              <FormDescription>Receive notifications for safety alerts in your area</FormDescription>
                            </div>
                            <FormControl>
                              <Switch 
                                checked={field.value} 
                                onCheckedChange={field.onChange} 
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="locationSharing"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center justify-between p-3 rounded-md bg-neutral-50">
                            <div>
                              <FormLabel className="font-medium">Location Sharing</FormLabel>
                              <FormDescription>Share your location with other travelers</FormDescription>
                            </div>
                            <FormControl>
                              <Switch 
                                checked={field.value} 
                                onCheckedChange={field.onChange} 
                              />
                            </FormControl>
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="flex justify-end">
                      <Button type="submit" className="bg-primary text-white">
                        Save Changes
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          )}
          
          {/* My Trips Tab */}
          {activeTab === "trips" && (
            <Card>
              <CardHeader>
                <CardTitle>My Trips</CardTitle>
                <CardDescription>
                  Manage your upcoming and past travel plans
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-6 text-center bg-neutral-50 rounded-lg">
                    <div className="text-6xl text-neutral-300 mb-4">
                      <i className="fas fa-suitcase"></i>
                    </div>
                    <h3 className="text-xl font-medium text-neutral-700 mb-2">No Trips Yet</h3>
                    <p className="text-neutral-600 mb-4">
                      You haven't added any trips yet. Start planning your next adventure!
                    </p>
                    <Button className="bg-primary text-white">
                      <i className="fas fa-plus mr-2"></i> Add New Trip
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {/* My Stories Tab */}
          {activeTab === "stories" && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>My Stories</CardTitle>
                  <CardDescription>
                    View and manage the theft stories you've shared
                  </CardDescription>
                </div>
                <Link href="/share-story">
                  <Button className="bg-primary text-white">
                    <i className="fas fa-plus mr-2"></i> Share Story
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Sample story */}
                  <div className="border rounded-lg p-4 hover:bg-neutral-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-medium text-lg">Pickpocketing in Barcelona Metro</h3>
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        Pickpocketing
                      </Badge>
                    </div>
                    <div className="flex items-center text-sm text-neutral-500 mb-2">
                      <span><i className="fas fa-map-marker-alt mr-1"></i> Barcelona, Spain</span>
                      <span className="mx-3">•</span>
                      <span><i className="far fa-calendar-alt mr-1"></i> May 15, 2023</span>
                    </div>
                    <p className="text-neutral-600 line-clamp-2 mb-3">
                      While riding the crowded L1 metro line during rush hour, I felt someone bump into me. Later, I discovered my wallet was missing from my back pocket. I immediately reported it to the metro security.
                    </p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-4 text-neutral-500 text-sm">
                        <span><i className="far fa-thumbs-up mr-1"></i> 34 Likes</span>
                        <span><i className="far fa-comment mr-1"></i> 12 Comments</span>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <i className="fas fa-edit mr-1"></i> Edit
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-50 border-red-200">
                          <i className="fas fa-trash mr-1"></i> Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Add more stories here */}
                  <Link href="/share-story">
                    <div className="border border-dashed rounded-lg p-6 text-center hover:bg-neutral-50 transition-colors cursor-pointer">
                      <div className="text-4xl text-neutral-300 mb-2">
                        <i className="fas fa-plus-circle"></i>
                      </div>
                      <p className="text-neutral-600">Share a new theft story</p>
                    </div>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
