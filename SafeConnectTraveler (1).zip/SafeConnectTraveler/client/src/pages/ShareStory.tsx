import { useState } from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertStorySchema } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'wouter';

// Extend the insert schema with additional validations
const formSchema = insertStorySchema.extend({
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(20, "Please provide a detailed description of what happened"),
  incidentType: z.string().min(1, "Please select an incident type"),
  location: z.string().min(1, "Please enter a location"),
  country: z.string().min(1, "Please enter a country"),
  incidentDate: z.date({
    required_error: "Please select a date",
  }).max(new Date(), "Date cannot be in the future"),
  preventionTips: z.array(z.string()).min(1, "Please provide at least one prevention tip"),
  newTip: z.string().optional(),
});

export default function ShareStory() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [newTip, setNewTip] = useState('');
  
  // Create form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: '',
      content: '',
      incidentType: '',
      location: '',
      country: '',
      incidentDate: new Date(),
      preventionTips: [],
      userId: 1, // Hardcoded for demo
    },
  });
  
  // Create mutation
  const mutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      // Remove the newTip field which is not part of the schema
      const { newTip, ...storyData } = values;
      
      // Send the story data to the API
      const response = await apiRequest('POST', '/api/stories', storyData);
      return response.json();
    },
    onSuccess: () => {
      // Show success toast
      toast({
        title: "Story Shared Successfully",
        description: "Thank you for sharing your experience. Your story will help other travelers stay safe.",
        variant: "default",
      });
      
      // Invalidate queries to refetch stories
      queryClient.invalidateQueries({ queryKey: ['/api/stories'] });
      
      // Navigate back to stories section
      navigate('/#stories');
    },
    onError: (error) => {
      // Show error toast
      toast({
        title: "Error Sharing Story",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    }
  });
  
  // Handle form submission
  function onSubmit(values: z.infer<typeof formSchema>) {
    mutation.mutate(values);
  }
  
  // Handle adding a new prevention tip
  function handleAddTip() {
    if (newTip.trim() === '') return;
    
    const currentTips = form.getValues('preventionTips') || [];
    form.setValue('preventionTips', [...currentTips, newTip.trim()]);
    setNewTip('');
  }
  
  // Handle removing a prevention tip
  function handleRemoveTip(index: number) {
    const currentTips = form.getValues('preventionTips') || [];
    form.setValue('preventionTips', currentTips.filter((_, i) => i !== index));
  }

  const incidentTypes = [
    "Pickpocketing",
    "Scam",
    "Robbery",
    "Card Skimming",
    "Bag Snatching",
    "Other"
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-4">
        <Link href="/#stories">
          <a className="text-primary hover:underline inline-flex items-center">
            <i className="fas fa-arrow-left mr-2"></i> Back to Theft Stories
          </a>
        </Link>
      </div>
      
      <div className="max-w-3xl mx-auto">
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="text-2xl font-heading">Share Your Theft Story</CardTitle>
            <CardDescription>
              Help fellow travelers stay safe by sharing your experience and prevention tips.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Title */}
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="E.g., Pickpocketing in Barcelona Metro" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Incident Type */}
                <FormField
                  control={form.control}
                  name="incidentType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Incident Type</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select incident type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {incidentTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Location and Country */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City/Location</FormLabel>
                        <FormControl>
                          <Input placeholder="E.g., Barcelona" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input placeholder="E.g., Spain" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* Incident Date */}
                <FormField
                  control={form.control}
                  name="incidentDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>When did this happen?</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${!field.value ? "text-muted-foreground" : ""}`}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <i className="fas fa-calendar-alt ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Story Content */}
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>What happened? (Please provide details)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe the incident in detail. What happened? Where exactly? How did it occur? Were there any warning signs?" 
                          className="min-h-[150px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Prevention Tips */}
                <FormField
                  control={form.control}
                  name="preventionTips"
                  render={() => (
                    <FormItem>
                      <FormLabel>Prevention Tips (What can others do to avoid this?)</FormLabel>
                      
                      <div className="mb-2">
                        <div className="flex">
                          <Input
                            placeholder="E.g., Keep valuables in front pockets"
                            value={newTip}
                            onChange={(e) => setNewTip(e.target.value)}
                            className="rounded-r-none"
                          />
                          <Button 
                            type="button" 
                            onClick={handleAddTip}
                            className="rounded-l-none"
                          >
                            Add
                          </Button>
                        </div>
                      </div>
                      
                      {/* Display added tips */}
                      <div className="bg-neutral-50 p-3 rounded-lg">
                        {form.watch('preventionTips')?.length > 0 ? (
                          <ul className="space-y-2">
                            {form.watch('preventionTips').map((tip, index) => (
                              <li key={index} className="flex justify-between items-center bg-white p-2 rounded">
                                <span>{tip}</span>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRemoveTip(index)}
                                  className="h-8 w-8 p-0 text-neutral-500 hover:text-red-500"
                                >
                                  <i className="fas fa-times"></i>
                                </Button>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-neutral-500 text-sm italic">No tips added yet. Please add at least one prevention tip.</p>
                        )}
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Disclaimer */}
                <div className="bg-neutral-100 p-4 rounded-lg text-sm text-neutral-600">
                  <p className="font-medium mb-1">
                    <i className="fas fa-info-circle mr-2 text-primary"></i>
                    By sharing your story, you agree to:
                  </p>
                  <ul className="list-disc list-inside space-y-1 pl-4">
                    <li>Share only your personal experience</li>
                    <li>Provide accurate information to help others</li>
                    <li>Allow SafeConnect to display your story to other travelers</li>
                  </ul>
                </div>
                
                {/* Submit Button */}
                <div className="flex justify-end">
                  <Button 
                    type="submit" 
                    className="bg-primary text-white font-medium py-2 px-4 rounded-lg hover:bg-primary-dark transition-colors"
                    disabled={mutation.isPending}
                  >
                    {mutation.isPending ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent align-[-0.125em]"></div>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-paper-plane mr-2"></i>
                        Share Your Story
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
