import { useParams, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { format } from 'date-fns';

export default function StoryDetail() {
  const { id } = useParams<{ id: string }>();
  const storyId = parseInt(id);

  // Fetch story details
  const { data: story, isLoading } = useQuery({
    queryKey: [`/api/stories/${storyId}`],
    enabled: Boolean(storyId),
  });

  if (isLoading || !story) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center h-[60vh]">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <span className="ml-3">Loading story details...</span>
        </div>
      </div>
    );
  }

  // Format date
  const formattedDate = format(new Date(story.incidentDate), 'MMMM d, yyyy');

  // Get incident type color
  const getIncidentTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pickpocketing':
        return 'bg-yellow-100 text-yellow-800';
      case 'scam':
        return 'bg-orange-100 text-orange-800';
      case 'robbery':
        return 'bg-red-100 text-red-800';
      case 'card skimming':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-neutral-100 text-neutral-800';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-4">
        <Link href="/#stories">
          <a className="text-primary hover:underline inline-flex items-center">
            <i className="fas fa-arrow-left mr-2"></i> Back to Theft Stories
          </a>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {/* Main Story */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h1 className="font-heading font-bold text-2xl">{story.title}</h1>
                <div className={`${getIncidentTypeColor(story.incidentType)} text-sm font-medium py-1 px-3 rounded-full`}>
                  {story.incidentType}
                </div>
              </div>
              
              <div className="flex items-center text-sm text-neutral-500 mb-6">
                <span><i className="fas fa-map-marker-alt mr-1"></i> {story.location}, {story.country}</span>
                <span className="mx-3">•</span>
                <span><i className="far fa-calendar-alt mr-1"></i> {formattedDate}</span>
              </div>
              
              <div className="prose max-w-none mb-6">
                <p className="text-neutral-700 whitespace-pre-line">{story.content}</p>
              </div>
              
              {/* Prevention Tips */}
              <div className="bg-neutral-100 p-5 rounded-lg mb-6">
                <h2 className="font-medium text-lg text-neutral-800 mb-3 flex items-center">
                  <i className="fas fa-lightbulb text-yellow-500 mr-2"></i> Prevention Tips
                </h2>
                <ul className="space-y-2">
                  {story.preventionTips.map((tip: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <i className="fas fa-check-circle text-[#34A853] mt-1 mr-3"></i>
                      <span className="text-neutral-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* User Info and Actions */}
              <div className="flex flex-wrap justify-between items-center pt-4 border-t border-neutral-200">
                <div className="flex items-center mb-3 md:mb-0">
                  <div className="w-10 h-10 rounded-full bg-neutral-300 flex items-center justify-center mr-3">
                    <i className="fas fa-user text-neutral-500"></i>
                  </div>
                  <div>
                    <p className="font-medium">
                      {story.user ? story.user.fullName || story.user.username : `User ${story.userId}`}
                    </p>
                    <p className="text-sm text-neutral-500">
                      {format(new Date(story.createdAt), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>
                <div className="flex space-x-4">
                  <button className="flex items-center text-neutral-500 hover:text-primary transition-colors">
                    <i className="far fa-bookmark mr-2"></i>
                    <span>Save</span>
                  </button>
                  <button className="flex items-center text-neutral-500 hover:text-primary transition-colors">
                    <i className="far fa-thumbs-up mr-2"></i>
                    <span>Helpful ({story.likes})</span>
                  </button>
                  <button className="flex items-center text-neutral-500 hover:text-primary transition-colors">
                    <i className="far fa-share-square mr-2"></i>
                    <span>Share</span>
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Comments Section (Placeholder) */}
          <Card>
            <CardContent className="p-6">
              <h2 className="font-heading font-semibold text-xl mb-4">Comments ({story.comments})</h2>
              
              {/* Comment Input */}
              <div className="flex mb-6">
                <div className="w-10 h-10 rounded-full bg-neutral-300 flex items-center justify-center mr-3 flex-shrink-0">
                  <i className="fas fa-user text-neutral-500"></i>
                </div>
                <div className="flex-grow">
                  <textarea 
                    className="w-full border border-neutral-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                    placeholder="Share your thoughts or ask a question..."
                    rows={3}
                  ></textarea>
                  <div className="mt-2 text-right">
                    <Button className="bg-primary text-white">
                      Post Comment
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Sample Comments */}
              <div className="space-y-6">
                <div className="flex">
                  <div className="w-10 h-10 rounded-full bg-neutral-300 flex items-center justify-center mr-3 flex-shrink-0">
                    <i className="fas fa-user text-neutral-500"></i>
                  </div>
                  <div>
                    <div className="bg-neutral-50 p-3 rounded-lg">
                      <div className="flex justify-between items-center mb-1">
                        <h3 className="font-medium">Maria L.</h3>
                        <span className="text-xs text-neutral-500">2 days ago</span>
                      </div>
                      <p className="text-neutral-700">
                        Thank you for sharing this. I experienced something similar during my trip last month. The prevention tips are very helpful!
                      </p>
                    </div>
                    <div className="flex mt-2 text-sm">
                      <button className="text-neutral-500 hover:text-primary mr-4">
                        <i className="far fa-thumbs-up mr-1"></i> 5
                      </button>
                      <button className="text-neutral-500 hover:text-primary">
                        <i className="far fa-comment mr-1"></i> Reply
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="flex">
                  <div className="w-10 h-10 rounded-full bg-neutral-300 flex items-center justify-center mr-3 flex-shrink-0">
                    <i className="fas fa-user text-neutral-500"></i>
                  </div>
                  <div>
                    <div className="bg-neutral-50 p-3 rounded-lg">
                      <div className="flex justify-between items-center mb-1">
                        <h3 className="font-medium">James W.</h3>
                        <span className="text-xs text-neutral-500">1 week ago</span>
                      </div>
                      <p className="text-neutral-700">
                        I'm planning a trip to {story.location} next month. Does anyone know if this is still an issue in the area? Any additional tips would be appreciated.
                      </p>
                    </div>
                    <div className="flex mt-2 text-sm">
                      <button className="text-neutral-500 hover:text-primary mr-4">
                        <i className="far fa-thumbs-up mr-1"></i> 3
                      </button>
                      <button className="text-neutral-500 hover:text-primary">
                        <i className="far fa-comment mr-1"></i> Reply
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-1">
          {/* Similar Stories */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <h2 className="font-heading font-semibold text-xl mb-4">Similar Stories</h2>
              
              <div className="space-y-4">
                <Link href="/story/1">
                  <div className="bg-neutral-50 hover:bg-neutral-100 transition-colors p-3 rounded-lg cursor-pointer">
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="font-medium">Pickpocketing in Metro Station</h3>
                      <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-0.5 rounded">
                        Pickpocketing
                      </span>
                    </div>
                    <p className="text-sm text-neutral-500 mb-1">
                      <i className="fas fa-map-marker-alt mr-1"></i> Paris, France
                    </p>
                    <p className="text-xs text-neutral-600 line-clamp-2">
                      Lost my wallet during rush hour at Châtelet station...
                    </p>
                  </div>
                </Link>
                
                <Link href="/story/2">
                  <div className="bg-neutral-50 hover:bg-neutral-100 transition-colors p-3 rounded-lg cursor-pointer">
                    <div className="flex justify-between items-start mb-1">
                      <h3 className="font-medium">Fake Tour Guide Scam</h3>
                      <span className="bg-orange-100 text-orange-800 text-xs px-2 py-0.5 rounded">
                        Scam
                      </span>
                    </div>
                    <p className="text-sm text-neutral-500 mb-1">
                      <i className="fas fa-map-marker-alt mr-1"></i> Bangkok, Thailand
                    </p>
                    <p className="text-xs text-neutral-600 line-clamp-2">
                      Approached by a "friendly local" offering a special tour...
                    </p>
                  </div>
                </Link>
              </div>
              
              <div className="mt-4 text-center">
                <Link href="/#stories">
                  <a className="text-primary hover:underline text-sm">
                    View more stories →
                  </a>
                </Link>
              </div>
            </CardContent>
          </Card>
          
          {/* Safety Resources */}
          <Card>
            <CardContent className="p-6">
              <h2 className="font-heading font-semibold text-xl mb-4">Safety Resources</h2>
              
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-primary bg-opacity-10 p-2 rounded-full mt-1 mr-3">
                    <i className="fas fa-map-marked-alt text-primary"></i>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Safety Map</h3>
                    <p className="text-sm text-neutral-600 mb-2">
                      View the interactive safety map for {story.location} with alerts and safe zones.
                    </p>
                    <Link href="/#safety-map">
                      <a className="text-primary text-sm hover:underline">
                        View Safety Map →
                      </a>
                    </Link>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#34A853] bg-opacity-10 p-2 rounded-full mt-1 mr-3">
                    <i className="fas fa-comments text-[#34A853]"></i>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Connect with Travelers</h3>
                    <p className="text-sm text-neutral-600 mb-2">
                      Chat with other travelers in {story.country} to get real-time safety updates.
                    </p>
                    <Link href="/#chat">
                      <a className="text-primary text-sm hover:underline">
                        Join Chat Rooms →
                      </a>
                    </Link>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#EA4335] bg-opacity-10 p-2 rounded-full mt-1 mr-3">
                    <i className="fas fa-exclamation-triangle text-[#EA4335]"></i>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Emergency SOS</h3>
                    <p className="text-sm text-neutral-600 mb-2">
                      Set up the SOS feature before your trip to {story.country} for added safety.
                    </p>
                    <Link href="/profile">
                      <a className="text-primary text-sm hover:underline">
                        Configure SOS →
                      </a>
                    </Link>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
