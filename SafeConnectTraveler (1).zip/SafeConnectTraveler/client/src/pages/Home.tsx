import { useEffect } from "react";
import HeroSection from "@/components/home/HeroSection";
import FeaturesOverview from "@/components/home/FeaturesOverview";
import DestinationsSection from "@/components/home/DestinationsSection";
import SafetyMapSection from "@/components/home/SafetyMapSection";
import TheftStoriesSection from "@/components/home/TheftStoriesSection";
import ChatSection from "@/components/home/ChatSection";
import SOSSection from "@/components/home/SOSSection";
import { GeofencingSection } from "@/components/home/GeofencingSection";
import CtaSection from "@/components/home/CtaSection";

export default function Home() {
  // Smooth scroll functionality
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A' && target.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const targetId = target.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId as string);
        if (targetElement) {
          window.scrollTo({
            top: targetElement.getBoundingClientRect().top + window.scrollY - 80,
            behavior: 'smooth'
          });
        }
      }
    };

    document.addEventListener('click', handleClick);
    
    return () => {
      document.removeEventListener('click', handleClick);
    };
  }, []);

  return (
    <div>
      <HeroSection />
      <FeaturesOverview />
      <DestinationsSection />
      <SafetyMapSection />
      <TheftStoriesSection />
      <ChatSection />
      <SOSSection />
      <GeofencingSection />
      <CtaSection />
    </div>
  );
}
