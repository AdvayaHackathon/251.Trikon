import { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useWebSocket } from '@/lib/websocket';
import { useChat } from '@/hooks/use-chat';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

type Message = {
  id: number;
  roomId: number;
  userId: number;
  username: string;
  content: string;
  imageUrl?: string;
  timestamp: string;
};

export default function ChatRoom() {
  const { id } = useParams<{ id: string }>();
  const roomId = parseInt(id);
  const { socket, isConnected, joinChatRoom, leaveChatRoom, sendMessage } = useWebSocket();
  const { messages, sendChatMessage, userCount, loading } = useChat(roomId);
  const [messageText, setMessageText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch room details
  const { data: room, isLoading: roomLoading } = useQuery({
    queryKey: [`/api/chat-rooms/${roomId}`],
    enabled: Boolean(roomId),
  });

  // Join the chat room when component mounts
  useEffect(() => {
    if (roomId && isConnected) {
      joinChatRoom(roomId, 1); // Hardcoded user ID for demo

      // Cleanup when component unmounts
      return () => {
        leaveChatRoom();
      };
    }
  }, [roomId, isConnected, joinChatRoom, leaveChatRoom]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Group messages by date
  const getMessageDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return format(date, 'yyyy-MM-dd');
  };

  const messageGroups: Record<string, Message[]> = {};
  messages.forEach(message => {
    const date = getMessageDate(message.timestamp);
    if (!messageGroups[date]) {
      messageGroups[date] = [];
    }
    messageGroups[date].push(message);
  });

  // Handle send message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    sendChatMessage(messageText);
    setMessageText('');
  };

  if (roomLoading || !room) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-center h-[60vh]">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
          <span className="ml-3">Loading chat room...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-4">
        <Link href="/#chat">
          <a className="text-primary hover:underline inline-flex items-center">
            <i className="fas fa-arrow-left mr-2"></i> Back to Chat Rooms
          </a>
        </Link>
      </div>
      
      <div className="bg-white rounded-xl overflow-hidden shadow-lg mb-8">
        {/* Chat Header */}
        <div className="bg-primary text-white p-4 border-b border-primary-dark flex justify-between items-center">
          <div>
            <h1 className="font-heading font-semibold text-xl">{room.name}</h1>
            <div className="text-sm text-white text-opacity-90 flex items-center">
              <span><i className="fas fa-map-marker-alt mr-1"></i> {room.location}</span>
              <span className="mx-2">•</span>
              <span><i className="fas fa-users mr-1"></i> {userCount} travelers online</span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button className="text-white hover:text-white hover:bg-primary-dark p-2 rounded-full transition-colors">
              <i className="fas fa-info-circle"></i>
            </button>
            <button className="text-white hover:text-white hover:bg-primary-dark p-2 rounded-full transition-colors">
              <i className="fas fa-user-plus"></i>
            </button>
            <button className="text-white hover:text-white hover:bg-primary-dark p-2 rounded-full transition-colors">
              <i className="fas fa-ellipsis-v"></i>
            </button>
          </div>
        </div>
        
        {/* Chat Description */}
        <div className="bg-neutral-50 p-3 border-b border-neutral-200">
          <p className="text-sm text-neutral-600">{room.description}</p>
        </div>
        
        {/* Chat Messages */}
        <div className="flex-1 p-4 overflow-y-auto bg-neutral-50" style={{ height: '500px' }}>
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <span className="ml-3">Loading messages...</span>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full">
              <div className="text-6xl text-neutral-300 mb-4">
                <i className="fas fa-comments"></i>
              </div>
              <h3 className="text-xl font-medium text-neutral-600 mb-2">No Messages Yet</h3>
              <p className="text-neutral-500 max-w-md text-center mb-6">
                Be the first to start a conversation in this chat room!
              </p>
            </div>
          ) : (
            Object.entries(messageGroups).map(([date, groupMessages]) => (
              <div key={date}>
                {/* Date Separator */}
                <div className="text-center my-3">
                  <span className="bg-neutral-200 text-neutral-600 text-xs px-2 py-1 rounded-full">
                    {format(new Date(date), 'MMMM d, yyyy')}
                  </span>
                </div>
                
                {groupMessages.map(message => {
                  const isCurrentUser = message.userId === 1; // Hardcoded for demo
                  
                  return isCurrentUser ? (
                    // My Message
                    <div key={message.id} className="flex flex-row-reverse mb-4">
                      <div className="w-8 h-8 rounded-full bg-primary flex-shrink-0 ml-2 flex items-center justify-center text-white font-medium">
                        Y
                      </div>
                      <div>
                        <div className="flex flex-row-reverse items-center mb-1">
                          <span className="text-xs text-neutral-500 mr-2">
                            {format(new Date(message.timestamp), 'h:mm a')}
                          </span>
                          <span className="font-medium text-sm">You</span>
                        </div>
                        <div className="bg-primary text-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          {message.imageUrl && (
                            <img 
                              src={message.imageUrl}
                              alt="Shared image" 
                              className="w-full h-40 object-cover rounded-lg mb-2"
                            />
                          )}
                          <p>{message.content}</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    // Their Message
                    <div key={message.id} className="flex mb-4">
                      <div className="w-8 h-8 rounded-full bg-neutral-300 flex-shrink-0 mr-2 flex items-center justify-center">
                        {message.username.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="font-medium text-sm">{message.username}</span>
                          <span className="text-xs text-neutral-500 ml-2">
                            {format(new Date(message.timestamp), 'h:mm a')}
                          </span>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          {message.imageUrl && (
                            <img 
                              src={message.imageUrl}
                              alt="Shared image" 
                              className="w-full h-40 object-cover rounded-lg mb-2"
                            />
                          )}
                          <p className="text-neutral-800">{message.content}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Message Input */}
        <div className="p-3 bg-white border-t border-neutral-200">
          <form onSubmit={handleSendMessage} className="flex items-center">
            <button type="button" className="p-2 text-neutral-500 hover:text-primary">
              <i className="far fa-image"></i>
            </button>
            <button type="button" className="p-2 text-neutral-500 hover:text-primary">
              <i className="far fa-smile"></i>
            </button>
            <Input 
              type="text" 
              placeholder="Type your message..." 
              className="flex-1 border border-neutral-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary mx-2"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
            />
            <Button 
              type="submit"
              className="bg-primary text-white p-2 rounded-lg hover:bg-primary-dark transition-colors"
              disabled={!messageText.trim()}
            >
              <i className="fas fa-paper-plane"></i>
            </Button>
          </form>
        </div>
      </div>
      
      {/* Safety Tips Card */}
      <div className="bg-white rounded-xl p-4 shadow-md">
        <h3 className="font-heading font-semibold text-lg mb-3">
          <i className="fas fa-shield-alt text-secondary mr-2"></i> Safety Tips for {room.location}
        </h3>
        <ul className="text-neutral-600 space-y-2">
          <li><i className="fas fa-check-circle text-secondary mr-2"></i> Share your itinerary with a trusted contact</li>
          <li><i className="fas fa-check-circle text-secondary mr-2"></i> Keep valuables secure and avoid displaying expensive items</li>
          <li><i className="fas fa-check-circle text-secondary mr-2"></i> Be aware of common tourist scams in this area</li>
          <li><i className="fas fa-check-circle text-secondary mr-2"></i> Save local emergency numbers on your phone</li>
        </ul>
        <div className="mt-3 text-right">
          <Link href="/#safety-map">
            <a className="text-primary hover:underline text-sm font-medium">View safety map for this area →</a>
          </Link>
        </div>
      </div>
    </div>
  );
}
