import { useState, useCallback } from 'react';
import { getCurrentPosition } from '@/lib/geolocation';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface SosOptions {
  userId?: number;
  contacts?: string[];
}

interface UseSosReturn {
  isSending: boolean;
  sendSos: () => Promise<void>;
  sosResult: any;
  error: Error | null;
}

export const useSos = (options: SosOptions = {}): UseSosReturn => {
  const [isSending, setIsSending] = useState(false);
  const [sosResult, setSosResult] = useState<any>(null);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  const sendSos = useCallback(async () => {
    setIsSending(true);
    setError(null);
    
    try {
      // Get current position
      const position = await getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      });
      
      const { latitude, longitude } = position.coords;
      
      // Send SOS alert to the server
      const response = await apiRequest('POST', '/api/sos', {
        userId: options.userId || 1, // Default to 1 for demo
        latitude,
        longitude,
        contacts: options.contacts || [],
        timestamp: new Date().toISOString()
      });
      
      // Parse the response
      const result = await response.json();
      setSosResult(result);
      
      // Show success toast
      toast({
        title: "SOS Alert Sent",
        description: "Your emergency contacts have been notified with your location.",
        variant: "default",
      });
      
    } catch (err) {
      setError(err as Error);
      
      // Show error toast
      toast({
        title: "SOS Alert Failed",
        description: err instanceof Error ? err.message : "Could not send SOS alert",
        variant: "destructive",
      });
      
      console.error('Error sending SOS:', err);
    } finally {
      setIsSending(false);
    }
  }, [options.userId, options.contacts, toast]);

  return {
    isSending,
    sendSos,
    sosResult,
    error
  };
};
