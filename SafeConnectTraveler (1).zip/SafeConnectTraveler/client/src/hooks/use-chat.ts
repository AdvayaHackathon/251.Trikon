import { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from '@/lib/websocket';
import { useToast } from '@/hooks/use-toast';

type Message = {
  id?: number;
  roomId: number;
  userId: number;
  username: string;
  content: string;
  imageUrl?: string;
  timestamp: string;
};

type UserJoinedMessage = {
  type: 'user-joined';
  roomId: number;
  userId: number;
  username: string;
  timestamp: string;
  userCount: number;
};

type UserLeftMessage = {
  type: 'user-left';
  roomId: number;
  userId: number;
  timestamp: string;
  userCount: number;
};

type ChatMessage = {
  type: 'message';
  roomId: number;
  userId: number;
  username: string;
  content: string;
  imageUrl?: string;
  timestamp: string;
};

type RoomHistoryMessage = {
  type: 'room-history';
  roomId: number;
  messages: Message[];
};

type ServerMessage = UserJoinedMessage | UserLeftMessage | ChatMessage | RoomHistoryMessage;

export function useChat(roomId: number) {
  const { socket, isConnected, sendMessage } = useWebSocket();
  const [messages, setMessages] = useState<Message[]>([]);
  const [userCount, setUserCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // Handle incoming WebSocket messages
  useEffect(() => {
    if (!socket) return;

    const handleMessage = (event: MessageEvent) => {
      try {
        const data: ServerMessage = JSON.parse(event.data);
        
        // Only process messages for this room
        if ('roomId' in data && data.roomId !== roomId) return;
        
        switch (data.type) {
          case 'user-joined':
            setUserCount(data.userCount);
            toast({
              title: "User Joined",
              description: `${data.username} has joined the chat`,
              variant: "default",
            });
            break;
            
          case 'user-left':
            setUserCount(data.userCount);
            break;
            
          case 'message':
            setMessages(prev => [...prev, {
              roomId: data.roomId,
              userId: data.userId,
              username: data.username,
              content: data.content,
              imageUrl: data.imageUrl,
              timestamp: data.timestamp
            }]);
            break;
            
          case 'room-history':
            setMessages(data.messages);
            setLoading(false);
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    socket.addEventListener('message', handleMessage);
    
    // Cleanup on unmount
    return () => {
      socket.removeEventListener('message', handleMessage);
    };
  }, [socket, roomId, toast]);

  // Send a chat message
  const sendChatMessage = useCallback((content: string, imageUrl?: string) => {
    if (!isConnected) {
      toast({
        title: "Connection Error",
        description: "You are not connected to the chat server",
        variant: "destructive",
      });
      return;
    }
    
    sendMessage({
      type: 'message',
      content,
      imageUrl,
    });
  }, [isConnected, sendMessage, toast]);

  return {
    messages,
    userCount,
    loading,
    sendChatMessage,
  };
}
