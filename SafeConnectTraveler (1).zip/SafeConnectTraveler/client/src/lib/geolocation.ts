/**
 * Calculates the distance between two points on the Earth's surface using the Haversine formula.
 * @param lat1 - The latitude of the first point in decimal degrees
 * @param lon1 - The longitude of the first point in decimal degrees
 * @param lat2 - The latitude of the second point in decimal degrees
 * @param lon2 - The longitude of the second point in decimal degrees
 * @returns The distance between the two points in kilometers
 */
export function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c; // Distance in km
  
  return distance;
}

/**
 * Converts degrees to radians
 * @param deg - The angle in degrees
 * @returns The angle in radians
 */
function deg2rad(deg: number): number {
  return deg * (Math.PI/180);
}

/**
 * Gets the current position of the user
 * @returns A promise that resolves to the user's current position
 */
export function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser.'));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0
    });
  });
}

/**
 * Checks if a point is within a specified radius of another point
 * @param userLat - The latitude of the user's position
 * @param userLng - The longitude of the user's position
 * @param zoneLat - The latitude of the zone center
 * @param zoneLng - The longitude of the zone center
 * @param radiusKm - The radius of the zone in kilometers
 * @returns True if the user is within the zone, false otherwise
 */
export function isWithinZone(
  userLat: number,
  userLng: number,
  zoneLat: number,
  zoneLng: number,
  radiusKm: number
): boolean {
  const distance = calculateDistance(userLat, userLng, zoneLat, zoneLng);
  return distance <= radiusKm;
}

/**
 * Interface for geofence zone data
 */
export interface GeofenceZone {
  id: number;
  name: string;
  lat: number;
  lng: number;
  radius: number; // in kilometers
}

/**
 * Checks if a user is within any of the specified geofence zones
 * @param userLat - The latitude of the user's position
 * @param userLng - The longitude of the user's position
 * @param zones - An array of geofence zones to check against
 * @returns The zone the user is in, or null if not in any zone
 */
export function checkGeofenceZones(
  userLat: number,
  userLng: number,
  zones: GeofenceZone[]
): { zone: GeofenceZone; distance: number } | null {
  for (const zone of zones) {
    const distance = calculateDistance(userLat, userLng, zone.lat, zone.lng);
    if (distance <= zone.radius) {
      return { zone, distance };
    }
  }
  return null;
}