import React, { useEffect, useRef, useState } from "react";
import { getCurrentPosition } from "@/lib/geolocation";

// This declares the google maps types for TypeScript
declare global {
  interface Window {
    google: any;
    initMap: () => void;
  }
}

interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  title: string;
  type: string; // Could be "hospital", "police", "embassy", "alert", "theftHotspot"
  content?: string;
  icon?: string;
}

interface GoogleMapProps {
  height?: string | number;
  width?: string | number;
  markers?: MapMarker[];
  initialCenter?: { lat: number; lng: number };
  zoom?: number;
  onClick?: (e: any) => void;
  className?: string;
  apiKey?: string;
}

const DEFAULT_CENTER = { lat: 48.8566, lng: 2.3522 }; // Paris by default

// Marker colors by type - used in both Google Maps and fallback map
const MARKER_COLORS = {
  hospital: "#34A853",
  police: "#4285F4",
  embassy: "#9c27b0",
  alert: "#EA4335",
  theftHotspot: "#FF9800",
  user: "#4285F4"
};

export function GoogleMap({
  height = "100%",
  width = "100%",
  markers = [],
  initialCenter = DEFAULT_CENTER,
  zoom = 13,
  onClick,
  className = "",
  apiKey,
}: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any>(null);
  const [googleMapsLoaded, setGoogleMapsLoaded] = useState(false);
  const [googleMapsLoadError, setGoogleMapsLoadError] = useState(false);
  const [center, setCenter] = useState(initialCenter);
  const [userPositionLoaded, setUserPositionLoaded] = useState(false);
  const markersRef = useRef<any[]>([]);
  
  // Load Google Maps API
  useEffect(() => {
    if (window.google?.maps) {
      setGoogleMapsLoaded(true);
      return;
    }
    
    const handleScriptError = () => {
      console.error("Failed to load Google Maps API");
      setGoogleMapsLoadError(true);
    };
    
    // Only load the script once
    if (!document.getElementById('google-maps-script')) {
      const googleMapsScript = document.createElement('script');
      googleMapsScript.id = 'google-maps-script';
      googleMapsScript.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey || ''}&callback=initMap`;
      googleMapsScript.async = true;
      googleMapsScript.defer = true;
      googleMapsScript.onerror = handleScriptError;
      
      // Set a timeout to detect if Google Maps fails to load
      const timeoutId = setTimeout(() => {
        if (!window.google?.maps) {
          handleScriptError();
        }
      }, 10000); // 10 seconds timeout
      
      window.initMap = () => {
        clearTimeout(timeoutId);
        setGoogleMapsLoaded(true);
      };
      
      document.head.appendChild(googleMapsScript);
    }
    
    return () => {
      window.initMap = () => {};
    };
  }, [apiKey]);
  
  // Load user position if available
  useEffect(() => {
    if (!userPositionLoaded) {
      getCurrentPosition()
        .then((position) => {
          setCenter({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          setUserPositionLoaded(true);
        })
        .catch((error) => {
          console.error("Error getting current location:", error);
          // Keep the default center if user location is not available
        });
    }
  }, [userPositionLoaded]);

  // Initialize map
  useEffect(() => {
    if (!googleMapsLoaded || !mapRef.current) return;
    
    // Create Google Map
    const newMap = new window.google.maps.Map(mapRef.current, {
      center,
      zoom,
      styles: [
        {
          featureType: "poi",
          elementType: "labels",
          stylers: [{ visibility: "off" }]
        }
      ],
      fullscreenControl: false,
      streetViewControl: false,
      mapTypeControl: false,
    });
    
    // Add click handler
    if (onClick) {
      newMap.addListener("click", onClick);
    }
    
    setMap(newMap);
    
    return () => {
      // Cleanup if needed
    };
  }, [googleMapsLoaded, center, zoom, onClick]);
  
  // Add user marker and update center
  useEffect(() => {
    if (!map || !userPositionLoaded) return;
    
    // Clear old user marker if exists
    if (markersRef.current[0]) {
      markersRef.current[0].setMap(null);
    }
    
    // Create user marker
    const userMarker = new window.google.maps.Marker({
      position: center,
      map,
      icon: {
        path: window.google.maps.SymbolPath.CIRCLE,
        scale: 10,
        fillColor: "#4285F4",
        fillOpacity: 1,
        strokeColor: "#FFFFFF",
        strokeWeight: 2,
      },
      title: "Your Location",
    });
    
    // Add user location accuracy circle
    const userAccuracyCircle = new window.google.maps.Circle({
      map,
      center,
      radius: 100, // meters
      fillColor: "#4285F4",
      fillOpacity: 0.15,
      strokeColor: "#4285F4",
      strokeOpacity: 0.5,
      strokeWeight: 1,
    });
    
    markersRef.current[0] = userMarker;
    map.setCenter(center);
    
    // Add button to recenter map on user location
    const centerControlDiv = document.createElement("div");
    centerControlDiv.className = "centerControl";
    centerControlDiv.style.margin = "10px";
    centerControlDiv.style.position = "absolute";
    centerControlDiv.style.bottom = "25px";
    centerControlDiv.style.right = "25px";
    
    const controlButton = document.createElement("button");
    controlButton.style.backgroundColor = "#fff";
    controlButton.style.border = "none";
    controlButton.style.borderRadius = "2px";
    controlButton.style.boxShadow = "0 1px 4px rgba(0,0,0,0.3)";
    controlButton.style.cursor = "pointer";
    controlButton.style.height = "40px";
    controlButton.style.width = "40px";
    controlButton.style.padding = "0";
    controlButton.style.textAlign = "center";
    controlButton.style.display = "flex";
    controlButton.style.alignItems = "center";
    controlButton.style.justifyContent = "center";
    
    const icon = document.createElement("i");
    icon.className = "fas fa-location-arrow";
    icon.style.color = "#4285F4";
    icon.style.fontSize = "16px";
    
    controlButton.appendChild(icon);
    centerControlDiv.appendChild(controlButton);
    
    controlButton.addEventListener("click", () => {
      map.setCenter(center);
      map.setZoom(15);
    });
    
    map.controls[window.google.maps.ControlPosition.RIGHT_BOTTOM].push(centerControlDiv);
    
    return () => {
      userMarker.setMap(null);
      userAccuracyCircle.setMap(null);
    };
  }, [map, center, userPositionLoaded]);
  
  // Add other markers
  useEffect(() => {
    if (!map) return;
    
    // Clear old markers
    markersRef.current.slice(1).forEach(marker => marker.setMap(null));
    markersRef.current = markersRef.current.slice(0, 1);
    
    // Add new markers
    markers.forEach(markerData => {
      const { lat, lng, title, type, content } = markerData;
      
      let icon;
      switch (type) {
        case "hospital":
          icon = {
            path: "M19 3h-4V1h-6v2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 11h-4v4h-4v-4H6v-4h4V6h4v4h4v4z",
            fillColor: "#34A853",
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 1.2,
            anchor: new window.google.maps.Point(12, 12),
          };
          break;
        case "police":
          icon = {
            path: "M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z",
            fillColor: "#4285F4",
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 1.2,
            anchor: new window.google.maps.Point(12, 12),
          };
          break;
        case "embassy":
          icon = {
            path: "M14.4 6L14 4H5v17h2v-7h5.6l.4 2h7V6z",
            fillColor: "#9c27b0",
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 1.2,
            anchor: new window.google.maps.Point(12, 12),
          };
          break;
        case "alert":
          icon = {
            path: "M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z",
            fillColor: "#EA4335",
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 1.2,
            anchor: new window.google.maps.Point(12, 12),
          };
          break;
        case "theftHotspot":
          icon = {
            path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z",
            fillColor: "#FF9800",
            fillOpacity: 1,
            strokeWeight: 0,
            scale: 1.2,
            anchor: new window.google.maps.Point(12, 12),
          };
          break;
        default:
          icon = null;
      }
      
      const marker = new window.google.maps.Marker({
        position: { lat, lng },
        map,
        icon,
        title,
      });
      
      if (content) {
        const infoWindow = new window.google.maps.InfoWindow({
          content,
        });
        
        marker.addListener("click", () => {
          infoWindow.open(map, marker);
        });
      }
      
      markersRef.current.push(marker);
    });
    
  }, [map, markers]);

  // Fallback map component when Google Maps API fails to load or there's no API key
  const FallbackMap = () => {
    // Calculate positions for markers on a relative grid
    const mapSize = { width: 700, height: 500 }; // Base size for calculations
    
    // Relative positioning
    const getRelativePosition = (
      lat: number, 
      lng: number, 
      centerLat = center.lat, 
      centerLng = center.lng
    ) => {
      // Simple conversion for demonstration (not geographically accurate)
      const latOffset = (lat - centerLat) * 2000;
      const lngOffset = (lng - centerLng) * 2000;
      
      // Position from center point
      const x = (mapSize.width / 2) + lngOffset;
      const y = (mapSize.height / 2) - latOffset; // Invert for y-axis
      
      return { x, y };
    };
    
    // Group markers by type
    const groupedMarkers = markers.reduce((groups, marker) => {
      const type = marker.type || 'default';
      if (!groups[type]) groups[type] = [];
      groups[type].push(marker);
      return groups;
    }, {} as Record<string, MapMarker[]>);
    
    return (
      <div 
        style={{ 
          height, 
          width, 
          position: 'relative',
          overflow: 'hidden',
          backgroundColor: '#e5e7eb', // Light gray background
          borderRadius: '8px',
          boxShadow: 'inset 0 0 10px rgba(0,0,0,0.1)'
        }}
        className={className}
      >
        {/* Map Title & Instructions */}
        <div style={{ 
          position: 'absolute', 
          top: 0, 
          left: 0, 
          right: 0,
          padding: '10px',
          backgroundColor: 'rgba(255,255,255,0.9)',
          borderBottom: '1px solid #ddd',
          zIndex: 10,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 'bold' }}>Safety Map</h3>
            <p style={{ margin: '4px 0 0', fontSize: '12px', color: '#666' }}>
              Displaying nearby safety information
            </p>
          </div>
          <div style={{ 
            fontSize: '12px', 
            backgroundColor: '#f3f4f6', 
            padding: '6px 10px', 
            borderRadius: '4px' 
          }}>
            API key required for interactive map
          </div>
        </div>
        
        {/* Map Markers */}
        <div style={{ 
          position: 'absolute', 
          top: 0, 
          left: 0, 
          right: 0, 
          bottom: 0, 
          padding: '50px 0 0' // Space for header
        }}>
          {/* Center marker (user location) */}
          <div style={{ 
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '20px',
            height: '20px',
            borderRadius: '50%',
            backgroundColor: MARKER_COLORS.user,
            border: '2px solid white',
            boxShadow: '0 0 0 10px rgba(66, 133, 244, 0.15)',
            zIndex: 5
          }}>
            <div style={{
              position: 'absolute',
              bottom: '26px',
              left: '-40px',
              width: '100px',
              textAlign: 'center',
              backgroundColor: 'white',
              padding: '4px 8px',
              borderRadius: '4px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
              fontSize: '12px',
              fontWeight: 'bold',
            }}>
              Your Location
            </div>
          </div>
          
          {/* Render all other markers */}
          {Object.entries(groupedMarkers).map(([type, typeMarkers]) => (
            typeMarkers.map(marker => {
              const pos = getRelativePosition(marker.lat, marker.lng);
              
              return (
                <div 
                  key={marker.id}
                  style={{
                    position: 'absolute',
                    top: `${(pos.y / mapSize.height) * 100}%`,
                    left: `${(pos.x / mapSize.width) * 100}%`,
                    transform: 'translate(-50%, -50%)',
                    width: '16px',
                    height: '16px',
                    borderRadius: '50%',
                    backgroundColor: MARKER_COLORS[type as keyof typeof MARKER_COLORS] || '#888',
                    border: '1px solid white',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                    cursor: 'pointer',
                    zIndex: 4
                  }}
                  title={marker.title}
                />
              );
            })
          ))}
        </div>
        
        {/* Legend */}
        <div style={{
          position: 'absolute',
          bottom: '10px',
          right: '10px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '8px 12px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          fontSize: '12px',
          zIndex: 10
        }}>
          <div style={{ fontWeight: 'bold', marginBottom: '6px' }}>Map Legend</div>
          {Object.entries(MARKER_COLORS).map(([type, color]) => (
            <div key={type} style={{ display: 'flex', alignItems: 'center', marginBottom: '4px' }}>
              <div style={{ 
                width: '10px', 
                height: '10px', 
                borderRadius: '50%', 
                backgroundColor: color,
                marginRight: '6px' 
              }}></div>
              <span style={{ textTransform: 'capitalize' }}>
                {type === 'theftHotspot' ? 'Theft Hotspot' : type}
              </span>
            </div>
          ))}
        </div>
        
        {/* Safety Tips */}
        <div style={{
          position: 'absolute',
          bottom: '10px',
          left: '10px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '10px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          maxWidth: '200px',
          fontSize: '12px',
          zIndex: 10
        }}>
          <div style={{ fontWeight: 'bold', marginBottom: '6px', color: '#d97706' }}>
            <span style={{ marginRight: '4px' }}>⚠️</span>
            Safety Tips
          </div>
          <ul style={{ margin: '0', paddingLeft: '16px' }}>
            <li style={{ marginBottom: '4px' }}>Keep valuables secure and out of sight</li>
            <li style={{ marginBottom: '4px' }}>Stay alert in crowded tourist areas</li>
            <li>Check in with your emergency contacts regularly</li>
          </ul>
        </div>
      </div>
    );
  };

  // Display loading placeholder while trying to load Google Maps
  if (!googleMapsLoaded && !googleMapsLoadError) {
    return (
      <div 
        style={{ 
          height, 
          width, 
          display: 'flex', 
          justifyContent: 'center', 
          alignItems: 'center',
          backgroundColor: '#f0f0f0',
          borderRadius: '8px'
        }}
        className={className}
      >
        <div style={{ textAlign: 'center', padding: '20px' }}>
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-lg font-medium">Loading safety map...</p>
          <p className="text-sm text-gray-500">Please wait while we load the interactive safety map</p>
        </div>
      </div>
    );
  }
  
  // Use fallback map if Google Maps failed to load
  if (googleMapsLoadError) {
    return <FallbackMap />;
  }

  // Google Maps loaded successfully
  return (
    <div
      ref={mapRef}
      style={{ height, width }}
      className={`map-container ${className}`}
    />
  );
}