import { useEffect, useRef, useState } from "react";
import { getCurrentPosition } from "@/lib/geolocation";

interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  title: string;
  type: "hospital" | "police" | "embassy" | "alert" | "theftHotspot";
  content?: string;
  icon?: string;
}

interface MapProps {
  height?: string | number;
  width?: string | number;
  markers?: MapMarker[];
  initialCenter?: { lat: number; lng: number };
  zoom?: number;
  onClick?: (e: google.maps.MapMouseEvent) => void;
  className?: string;
}

const DEFAULT_CENTER = { lat: 48.8566, lng: 2.3522 }; // Paris by default

export function Map({
  height = "100%",
  width = "100%",
  markers = [],
  initialCenter = DEFAULT_CENTER,
  zoom = 13,
  onClick,
  className = "",
}: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [center, setCenter] = useState(initialCenter);
  const [userPositionLoaded, setUserPositionLoaded] = useState(false);
  
  // Load user position if available
  useEffect(() => {
    if (!userPositionLoaded) {
      getCurrentPosition()
        .then((position) => {
          setCenter({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
          setUserPositionLoaded(true);
        })
        .catch((error) => {
          console.error("Error getting user location:", error);
          // Keep the default center if user location is not available
        });
    }
  }, [userPositionLoaded]);

  // Initialize map
  useEffect(() => {
    if (!mapRef.current) return;
    
    // For this implementation, we'll use a placeholder div since we don't have
    // actual Google Maps API integration in this demo
    const mapDiv = mapRef.current;
    mapDiv.innerHTML = "";
    mapDiv.style.position = "relative";
    mapDiv.style.overflow = "hidden";
    
    // Create map placeholder with blue background
    const mapPlaceholder = document.createElement("div");
    mapPlaceholder.style.position = "absolute";
    mapPlaceholder.style.top = "0";
    mapPlaceholder.style.left = "0";
    mapPlaceholder.style.width = "100%";
    mapPlaceholder.style.height = "100%";
    mapPlaceholder.style.backgroundColor = "#e6f2ff";
    mapPlaceholder.style.backgroundImage = "url('https://images.unsplash.com/photo-1569336415962-a4bd9f69c07b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80')";
    mapPlaceholder.style.backgroundSize = "cover";
    mapPlaceholder.style.backgroundPosition = "center";
    mapPlaceholder.style.opacity = "0.2";
    mapDiv.appendChild(mapPlaceholder);
    
    // Add map overlay text
    const overlayTextDiv = document.createElement("div");
    overlayTextDiv.style.position = "absolute";
    overlayTextDiv.style.top = "50%";
    overlayTextDiv.style.left = "50%";
    overlayTextDiv.style.transform = "translate(-50%, -50%)";
    overlayTextDiv.style.maxWidth = "80%";
    overlayTextDiv.style.background = "rgba(255, 255, 255, 0.8)";
    overlayTextDiv.style.padding = "12px 16px";
    overlayTextDiv.style.borderRadius = "8px";
    overlayTextDiv.style.textAlign = "center";
    overlayTextDiv.textContent = "Interactive safety map would appear here, showing safety zones, emergency services, and alerts based on your location.";
    mapDiv.appendChild(overlayTextDiv);
    
    // Add map controls
    const controlsDiv = document.createElement("div");
    controlsDiv.style.position = "absolute";
    controlsDiv.style.bottom = "16px";
    controlsDiv.style.right = "16px";
    controlsDiv.style.display = "flex";
    controlsDiv.style.flexDirection = "column";
    controlsDiv.style.gap = "8px";
    mapDiv.appendChild(controlsDiv);
    
    // Zoom in button
    const zoomInBtn = createMapButton("+");
    controlsDiv.appendChild(zoomInBtn);
    
    // Zoom out button
    const zoomOutBtn = createMapButton("-");
    controlsDiv.appendChild(zoomOutBtn);
    
    // Center on user button
    const centerBtn = createMapButton("<i class='fas fa-location-arrow'></i>", "primary");
    controlsDiv.appendChild(centerBtn);
    
    // Add marker indicators for sample data
    markers.forEach(marker => {
      addMarkerToMap(mapDiv, marker);
    });
    
    return () => {
      // Cleanup if needed
    };
  }, [center, markers, onClick]);
  
  // Helper function to create map control buttons
  function createMapButton(content: string, variant: string = "default") {
    const button = document.createElement("button");
    button.innerHTML = content;
    button.style.width = "40px";
    button.style.height = "40px";
    button.style.borderRadius = "50%";
    button.style.border = "none";
    button.style.display = "flex";
    button.style.alignItems = "center";
    button.style.justifyContent = "center";
    button.style.boxShadow = "0 2px 4px rgba(0,0,0,0.1)";
    button.style.cursor = "pointer";
    
    if (variant === "primary") {
      button.style.backgroundColor = "hsl(217, 89%, 61%)";
      button.style.color = "white";
    } else {
      button.style.backgroundColor = "white";
      button.style.color = "#333";
    }
    
    return button;
  }
  
  // Helper function to add marker to map
  function addMarkerToMap(mapDiv: HTMLDivElement, marker: MapMarker) {
    // This is just a placeholder implementation since we don't have actual Google Maps integration
    const { type } = marker;
    
    let color;
    let icon;
    
    switch (type) {
      case "hospital":
        color = "#34A853";
        icon = "fa-hospital";
        break;
      case "police":
        color = "#4285F4";
        icon = "fa-shield-alt";
        break;
      case "embassy":
        color = "#9c27b0";
        icon = "fa-flag";
        break;
      case "alert":
        color = "#EA4335";
        icon = "fa-exclamation-triangle";
        break;
      case "theftHotspot":
        color = "#FF9800";
        icon = "fa-exclamation-circle";
        break;
      default:
        color = "#4285F4";
        icon = "fa-map-marker-alt";
    }
    
    // Randomly position markers in the map for demo purposes
    const left = 10 + Math.random() * 80;
    const top = 10 + Math.random() * 80;
    
    const markerElement = document.createElement("div");
    markerElement.style.position = "absolute";
    markerElement.style.left = `${left}%`;
    markerElement.style.top = `${top}%`;
    markerElement.style.transform = "translate(-50%, -50%)";
    markerElement.style.width = "36px";
    markerElement.style.height = "36px";
    markerElement.style.backgroundColor = color;
    markerElement.style.color = "white";
    markerElement.style.borderRadius = "50%";
    markerElement.style.display = "flex";
    markerElement.style.alignItems = "center";
    markerElement.style.justifyContent = "center";
    markerElement.style.boxShadow = "0 2px 6px rgba(0,0,0,0.3)";
    markerElement.style.zIndex = "10";
    markerElement.innerHTML = `<i class="fas ${icon}"></i>`;
    markerElement.title = marker.title;
    
    mapDiv.appendChild(markerElement);
  }

  return (
    <div
      ref={mapRef}
      style={{ height, width }}
      className={`map-container ${className}`}
    />
  );
}
