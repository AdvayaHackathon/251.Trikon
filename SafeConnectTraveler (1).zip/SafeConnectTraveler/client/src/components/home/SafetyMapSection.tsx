import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { GoogleMap } from '@/components/ui/google-map';

interface MapLayer {
  id: string;
  label: string;
  checked: boolean;
}

interface Location {
  locationName: string;
  lat: number;
  long: number;
  safetyScore: number;
  safeTime: string;
  riskTime: string;
  mostCommonIssue: string; // Added to handle the missing property
}

export default function SafetyMapSection() {
  const [mapLayers, setMapLayers] = useState<MapLayer[]>([
    { id: 'safetyHeatmap', label: 'Safety Heatmap', checked: true },
    { id: 'hospitals', label: 'Hospitals', checked: true },
    { id: 'policeStations', label: 'Police Stations', checked: true },
    { id: 'embassies', label: 'Embassies', checked: false },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);
  const [coords, setCoords] = useState({ lat: 12.9716, lng: 77.5946 }); // Default: Bangalore

  useEffect(() => {
    // Fetch safety scores from API
    fetch('/api/safety-scores')
      .then(res => res.json())
      .then(data => {
        setLocations(data.map((item: any) => ({
          locationName: item.locationName,
          lat: item.lat,
          long: item.long,
          safetyScore: item.safetyScore,
          safeTime: item.safeTime,
          riskTime: item.riskTime,
          mostCommonIssue: item.mostCommonIssue || "" // Handle missing data gracefully
        })));
      })
      .catch(err => console.error('Error fetching safety data:', err));
  }, []);

  const handleLocationSelect = (location: Location) => {
    setSelectedLocation(location);
    setCoords({ lat: location.lat, lng: location.long });
  };

  const getSafetyColor = (score: number) => {
    if (score >= 80) return '#34A853'; // Green for safe (80-100)
    if (score >= 50) return '#FBBC04'; // Orange for moderate safe (50-80)
    return '#EA4335'; // Red for unsafe (below 50)
  };

  const getSafetyLabel = (score: number) => {
    if (score >= 80) return 'Safe Zone';
    if (score >= 50) return 'Moderate Safe';
    return 'Unsafe Zone';
  };

  const filteredLocations = locations.filter(location =>
    location.locationName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section id="safety-map" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="font-heading font-bold text-3xl mb-4">Safety Map</h2>
          <p className="text-neutral-600">View safety information and emergency services.</p>
        </div>

        <div className="bg-neutral-100 rounded-xl overflow-hidden shadow-lg p-4 md:p-0">
          <div className="flex flex-col md:flex-row">
            {/* Map Controls Sidebar */}
            <div className="md:w-1/4 bg-white md:rounded-l-xl p-4 md:p-6">
              <h3 className="font-heading font-semibold text-xl mb-4">Map Controls</h3>

              {/* Search Bar */}
              <div className="mb-6">
                <Label className="block text-neutral-700 font-medium mb-2">Search Location</Label>
                <Input
                  type="text"
                  placeholder="Search for a location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full"
                />
                {searchQuery && (
                  <div className="mt-2 max-h-48 overflow-y-auto bg-white rounded border">
                    {filteredLocations.map(location => (
                      <button
                        key={location.locationName}
                        onClick={() => handleLocationSelect(location)}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 flex items-center justify-between"
                      >
                        <span>{location.locationName}</span>
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: getSafetyColor(location.safetyScore) }}
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Selected Location Info */}
              {selectedLocation && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">{selectedLocation.locationName}</h4>
                  <div className="space-y-2 text-sm">
                    <p className="flex items-center justify-between">
                      Safety Score:
                      <span className="font-medium" style={{ color: getSafetyColor(selectedLocation.safetyScore) }}>
                        {selectedLocation.safetyScore}% ({getSafetyLabel(selectedLocation.safetyScore)})
                      </span>
                    </p>
                    <p className="flex items-center justify-between">
                      Safe Hours: <span className="text-green-600">{selectedLocation.safeTime}</span>
                    </p>
                    <p className="flex items-center justify-between">
                      Risk Hours: <span className="text-red-600">{selectedLocation.riskTime}</span>
                    </p>
                    <p className="flex items-center justify-between">
                      Common Issue: <span className="text-gray-600">{selectedLocation.mostCommonIssue}</span>
                    </p>
                  </div>
                </div>
              )}

              {/* Map Layers */}
              <div className="mb-6">
                <Label className="block text-neutral-700 font-medium mb-2">Map Layers</Label>
                <div className="space-y-2">
                  {mapLayers.map(layer => (
                    <div key={layer.id} className="flex items-center">
                      <Checkbox
                        id={layer.id}
                        checked={layer.checked}
                        onCheckedChange={() => {
                          setMapLayers(prevLayers =>
                            prevLayers.map(l =>
                              l.id === layer.id ? { ...l, checked: !l.checked } : l
                            )
                          );
                        }}
                        className="w-4 h-4 text-primary"
                      />
                      <Label htmlFor={layer.id} className="ml-2 text-neutral-700">{layer.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Map Display */}
            <div className="md:w-3/4 h-[450px] relative mt-4 md:mt-0">
              <GoogleMap
                height="100%"
                width="100%"
                initialCenter={coords}
                zoom={13}
                markers={locations.map(location => ({
                  id: location.locationName,
                  lat: location.lat,
                  lng: location.long,
                  title: `${location.locationName} (Safety: ${location.safetyScore}%)`,
                  color: getSafetyColor(location.safetyScore)
                }))}
                apiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ""}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}