import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useState } from "react";
import { getCurrentPosition } from "@/lib/geolocation";

export default function SOSSection() {
  const [activatingSOS, setActivatingSOS] = useState(false);

  const handleSOSClick = async () => {
    if (window.confirm("This will activate the SOS feature and send your current location to emergency contacts. Continue?")) {
      setActivatingSOS(true);
      
      try {
        // Get current position
        const position = await getCurrentPosition();
        const { latitude, longitude } = position.coords;
        
        // Simulate contacting emergency services with location
        setTimeout(() => {
          alert(`Emergency SOS activated! Your current location (${latitude.toFixed(6)}, ${longitude.toFixed(6)}) has been sent to emergency services and your emergency contacts.`);
          setActivatingSOS(false);
        }, 2000);
      } catch (error) {
        alert("Unable to get your location. Please enable location services and try again.");
        setActivatingSOS(false);
      }
    }
  };

  return (
    <section className="py-16 relative overflow-hidden bg-cover bg-center" 
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1494783367193-149034c05e8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')`,
        backgroundAttachment: "fixed"
      }}>
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Tourism Quote */}
        <div className="text-center mb-12">
          <h2 className="font-heading font-bold text-3xl md:text-4xl text-white mb-4 leading-tight">
            "The world is a book and those who do not travel read only one page."
          </h2>
          <p className="text-white text-opacity-90 italic">― Saint Augustine</p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden backdrop-blur-sm bg-opacity-95">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12">
                <h2 className="font-heading font-bold text-3xl mb-4">Emergency SOS Feature</h2>
                <p className="text-neutral-700 mb-6">
                  Our SOS button provides instant help in emergency situations by alerting your trusted contacts with your real-time location.
                </p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start">
                    <div className="bg-[#EA4335] bg-opacity-10 rounded-full p-2 mt-1 mr-4">
                      <i className="fas fa-location-arrow text-[#EA4335]"></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-lg mb-1">Real-time Location Sharing</h3>
                      <p className="text-neutral-600 text-sm">Automatically sends your precise GPS coordinates to your emergency contacts.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-[#EA4335] bg-opacity-10 rounded-full p-2 mt-1 mr-4">
                      <i className="fas fa-bell text-[#EA4335]"></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-lg mb-1">Instant Notifications</h3>
                      <p className="text-neutral-600 text-sm">Your contacts receive immediate SMS and app notifications with a map link to your location.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-[#EA4335] bg-opacity-10 rounded-full p-2 mt-1 mr-4">
                      <i className="fas fa-phone-alt text-[#EA4335]"></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-lg mb-1">Local Emergency Services</h3>
                      <p className="text-neutral-600 text-sm">One-touch access to local emergency numbers wherever you are traveling.</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4">
                  <Button 
                    onClick={handleSOSClick} 
                    className={`sos-button bg-[#EA4335] hover:bg-red-700 text-white font-bold py-3 px-6 rounded-lg mb-3 sm:mb-0 transition duration-300 flex items-center justify-center h-auto ${activatingSOS ? 'animate-pulse' : ''}`}
                    disabled={activatingSOS}
                  >
                    <i className="fas fa-exclamation-triangle mr-2"></i> 
                    {activatingSOS ? "Activating SOS..." : "Activate SOS"}
                  </Button>
                  
                  <Link href="/profile" className="text-primary hover:underline text-center">
                    Set up emergency contacts →
                  </Link>
                </div>
              </div>
              
              <div className="hidden md:block relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1599300629124-6dca0a70fcc5?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Emergency services helping a traveler" 
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent opacity-50"></div>
                <div className="absolute bottom-6 left-6 max-w-xs text-white">
                  <div className="font-heading font-bold text-xl mb-2">Peace of mind for solo travelers</div>
                  <p className="text-sm text-white text-opacity-90">
                    "The SOS feature helped me when I felt unsafe in an unfamiliar neighborhood. My sister received my location immediately."
                  </p>
                  <div className="mt-2 flex items-center">
                    <div className="w-8 h-8 rounded-full bg-neutral-300 mr-2">
                      <img 
                        src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                        alt="User testimonial" 
                        className="w-full h-full rounded-full"
                      />
                    </div>
                    <span className="text-xs">Jamie L., Solo Traveler</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
