import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, MapPin, CheckCircle2, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { calculateDistance } from '@/lib/geolocation';

// Define safety zone coordinates
const SAFETY_ZONES = [
  { id: 1, name: 'Hebbal, Bangalore', lat: 13.0352, lng: 77.5970, radius: 20 },
  { id: 2, name: 'MG Road, Bangalore', lat: 12.9757, lng: 77.6014, radius: 15 },
  { id: 3, name: 'Indiranagar, Bangalore', lat: 12.9784, lng: 77.6408, radius: 10 }
];

interface CheckResult {
  status: 'inside' | 'outside' | null;
  distance: number | null;
  zoneName: string | null;
}

export function GeofencingSection() {
  const [isChecking, setIsChecking] = useState(false);
  const [result, setResult] = useState<CheckResult>({ 
    status: null, 
    distance: null, 
    zoneName: null 
  });
  const [geolocationSupported, setGeolocationSupported] = useState(true);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [notificationSupported, setNotificationSupported] = useState(false);
  const { toast } = useToast();
  
  useEffect(() => {
    // Check if geolocation is supported
    if (!navigator.geolocation) {
      setGeolocationSupported(false);
    }
    
    // Check if notifications are supported
    if ('Notification' in window) {
      setNotificationSupported(true);
      Notification.requestPermission();
    }
  }, []);
  
  const checkLocation = () => {
    setIsChecking(true);
    setResult({ status: null, distance: null, zoneName: null });
    
    navigator.geolocation.getCurrentPosition(
      // Success callback
      async (position) => {
        const userLat = position.coords.latitude;
        const userLng = position.coords.longitude;
        
        try {
          // Find the closest safety zone to check against
          let closestZone = null;
          let minDistance = Infinity;
          
          for (const zone of SAFETY_ZONES) {
            const distance = calculateDistance(
              userLat, userLng,
              zone.lat, zone.lng
            );
            
            if (distance < minDistance) {
              minDistance = distance;
              closestZone = zone;
            }
          }
          
          if (closestZone) {
            // Call the geofencing API
            const response = await fetch(
              `/api/geofencing/check?lat=${userLat}&lng=${userLng}&targetLat=${closestZone.lat}&targetLng=${closestZone.lng}&radius=${closestZone.radius}`
            );
            
            if (!response.ok) {
              throw new Error('Failed to check geofencing');
            }
            
            const data = await response.json();
            
            setResult({
              status: data.status as 'inside' | 'outside',
              distance: data.distance,
              zoneName: closestZone.name
            });
            
            // Show notification if inside a zone
            if (data.status === 'inside' && Notification.permission === 'granted') {
              new Notification('SafeConnect Safety Zone Alert', {
                body: `You are within the safety zone: ${closestZone.name}!`,
                icon: '/icon-safe.png'
              });
            }
          }
        } catch (error) {
          console.error('Geofencing API error:', error);
          toast({
            title: 'Error',
            description: 'Could not check your location. Please try again.',
            variant: 'destructive'
          });
        } finally {
          setIsChecking(false);
        }
      },
      // Error callback
      (error) => {
        console.error('Geolocation error:', error);
        setIsChecking(false);
        
        if (error.code === error.PERMISSION_DENIED) {
          setPermissionDenied(true);
          toast({
            title: 'Location access denied',
            description: 'Please allow access to your location to use this feature.',
            variant: 'destructive'
          });
        } else {
          toast({
            title: 'Location error',
            description: 'Could not access your location. Please try again later.',
            variant: 'destructive'
          });
        }
      },
      // Options
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };
  
  const renderContent = () => {
    if (!geolocationSupported) {
      return (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Not Supported</AlertTitle>
          <AlertDescription>
            Geolocation is not supported by your browser. Please try using a different browser.
          </AlertDescription>
        </Alert>
      );
    }
    
    if (permissionDenied) {
      return (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Permission Denied</AlertTitle>
          <AlertDescription>
            Location access was denied. Please enable location permissions in your browser settings and refresh the page.
          </AlertDescription>
        </Alert>
      );
    }
    
    return (
      <>
        <div className="flex flex-col items-center space-y-4">
          <Button 
            onClick={checkLocation} 
            disabled={isChecking}
            size="lg"
            className="w-full sm:w-auto"
          >
            {isChecking ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking your location...
              </>
            ) : (
              <>
                <MapPin className="mr-2 h-4 w-4" />
                Check My Safety Zone
              </>
            )}
          </Button>
          
          {notificationSupported && Notification.permission !== 'granted' && (
            <Alert>
              <AlertTitle>Enable Notifications</AlertTitle>
              <AlertDescription>
                Enable notifications to receive alerts when you enter or leave a safety zone.
              </AlertDescription>
            </Alert>
          )}
        </div>
        
        {result.status && (
          <div className="mt-6">
            <Alert variant={result.status === 'inside' ? 'default' : 'destructive'}>
              {result.status === 'inside' ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <AlertCircle className="h-4 w-4" />
              )}
              <AlertTitle>
                {result.status === 'inside' ? 'Inside Safety Zone' : 'Outside Safety Zone'}
              </AlertTitle>
              <AlertDescription>
                You are {result.distance} km from {result.zoneName}.
                {result.status === 'inside' 
                  ? ' You are within the safety zone.' 
                  : ' This is outside the designated safety zone.'}
              </AlertDescription>
            </Alert>
          </div>
        )}
        
        <div className="mt-6">
          <h4 className="text-sm font-medium mb-2">Available Safety Zones:</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {SAFETY_ZONES.map(zone => (
              <div key={zone.id} className="flex items-center space-x-2">
                <Badge variant="outline">
                  <MapPin className="h-3 w-3 mr-1" />
                  {zone.name}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  ({zone.radius} km radius)
                </span>
              </div>
            ))}
          </div>
        </div>
      </>
    );
  };
  
  return (
    <div className="py-8 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold tracking-tight">Geofencing Protection</h2>
          <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
            Know when you're inside a designated safety zone with real-time geofencing alerts. 
            Stay aware of your surroundings while traveling.
          </p>
        </div>
        
        <Card className="max-w-xl mx-auto">
          <CardHeader>
            <CardTitle>Safety Zone Checker</CardTitle>
            <CardDescription>
              Check if your current location is within one of our designated safety zones.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderContent()}
          </CardContent>
          <CardFooter className="text-xs text-muted-foreground">
            Your location data is processed locally and never stored on our servers.
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}