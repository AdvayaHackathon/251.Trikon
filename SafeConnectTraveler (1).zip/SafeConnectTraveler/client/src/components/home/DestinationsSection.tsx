import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Destination } from '@shared/schema';

export default function DestinationsSection() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: destinations, isLoading } = useQuery({
    queryKey: ['/api/destinations'],
    staleTime: 60000, // 1 minute
  });

  const filteredDestinations = destinations?.filter(
    (dest: Destination) => 
      dest.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      dest.country.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const displayedDestinations = filteredDestinations.slice(0, 3);

  // Safety status badge color
  const getSafetyStatusColor = (status: string) => {
    if (status.includes("Very Safe") || status.includes("Safe for")) {
      return "bg-green-100 text-secondary";
    } else if (status.includes("Generally Safe")) {
      return "bg-blue-100 text-blue-700";
    } else if (status.includes("Moderate Caution")) {
      return "bg-yellow-100 text-yellow-800";
    } else {
      return "bg-red-100 text-red-700";
    }
  };

  // Safety score icon color
  const getSafetyScoreColor = (score: number) => {
    if (score >= 4.5) return "text-secondary";
    if (score >= 4.0) return "text-blue-500";
    if (score >= 3.5) return "text-yellow-500";
    return "text-red-500";
  };

  return (
    <section id="destinations" className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-10">
          <div>
            <h2 className="font-heading font-bold text-3xl mb-2">Safe Destinations</h2>
            <p className="text-neutral-600 max-w-2xl">Explore destinations with safety ratings and connect with fellow travelers.</p>
          </div>
          <div className="mt-4 md:mt-0">
            <div className="relative flex items-center max-w-md">
              <Input
                type="text"
                placeholder="Search destinations..."
                className="w-full py-3 px-4 pr-10 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button className="absolute right-3 text-neutral-500">
                <i className="fas fa-search"></i>
              </button>
            </div>
          </div>
        </div>
        
        {/* Destination Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <div className="col-span-3 text-center py-12">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <p className="mt-4 text-neutral-600">Loading destinations...</p>
            </div>
          ) : displayedDestinations.length > 0 ? (
            displayedDestinations.map((destination: Destination) => (
              <div key={destination.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={destination.imageUrl} 
                    alt={`${destination.name} cityscape`} 
                    className="w-full h-full object-cover transition-transform hover:scale-105"
                  />
                  <div className="absolute top-3 right-3 bg-white rounded-full px-3 py-1 text-sm font-semibold flex items-center">
                    <i className={`fas fa-shield-alt ${getSafetyScoreColor(destination.safetyScore)} mr-1`}></i>
                    <span>{destination.safetyScore}</span>/5
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-heading font-semibold text-xl mb-2">{destination.name}, {destination.country}</h3>
                  <div className="flex items-center text-sm mb-3">
                    <span className={`${getSafetyStatusColor(destination.safetyStatus)} rounded-full px-2 py-0.5 font-medium`}>
                      <i className="fas fa-check-circle mr-1"></i> {destination.safetyStatus}
                    </span>
                  </div>
                  <p className="text-neutral-600 mb-4 line-clamp-2">{destination.description}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div className="flex -space-x-2">
                        <div className="w-7 h-7 rounded-full bg-neutral-300 border-2 border-white flex items-center justify-center text-xs">
                          <i className="fas fa-user"></i>
                        </div>
                        <div className="w-7 h-7 rounded-full bg-neutral-300 border-2 border-white flex items-center justify-center text-xs">
                          <i className="fas fa-user"></i>
                        </div>
                        <div className="w-7 h-7 rounded-full bg-neutral-300 border-2 border-white flex items-center justify-center text-xs">
                          <i className="fas fa-user"></i>
                        </div>
                      </div>
                      <span className="text-sm text-neutral-600">+{destination.activeTravelers - 3} travelers</span>
                    </div>
                    <Link href={`/destination/${destination.id}`}>
                      <Button variant="link" className="text-primary font-medium hover:underline">Explore</Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-3 text-center py-12">
              <p className="text-neutral-600">No destinations found. Try a different search term.</p>
            </div>
          )}
          
          {/* More Destinations Button */}
          <div className="sm:col-span-2 lg:col-span-3 flex justify-center mt-6">
            <Button className="bg-white border border-primary text-primary hover:bg-primary hover:text-white transition-colors duration-300 font-medium rounded-lg px-8 py-3">
              View More Destinations
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
