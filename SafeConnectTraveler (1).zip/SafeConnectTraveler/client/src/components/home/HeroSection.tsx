import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useState, useEffect } from "react";

export default function HeroSection() {
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  
  // Collection of inspiring travel quotes
  const travelQuotes = [
    {
      quote: "Travel far, travel wide, travel safe.",
      author: "SafeConnect Motto"
    },
    {
      quote: "Travel isn't always pretty. It isn't always comfortable. But that's okay. The journey changes you.",
      author: "Anthony Bourdain"
    },
    {
      quote: "The real voyage of discovery consists not in seeking new landscapes, but in having new eyes.",
      author: "Marcel Proust"
    },
    {
      quote: "Adventure may hurt you, but monotony will kill you.",
      author: "Unknown"
    },
    {
      quote: "Not all who wander are lost.",
      author: "J.R.R. Tolkien"
    }
  ];
  
  // Rotate quotes every 8 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuoteIndex((prevIndex) => 
        prevIndex === travelQuotes.length - 1 ? 0 : prevIndex + 1
      );
    }, 8000);
    
    return () => clearInterval(interval);
  }, []);
  
  const currentQuote = travelQuotes[currentQuoteIndex];
  
  return (
    <section className="relative min-h-[80vh] flex items-center bg-cover bg-center" 
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.65)), url('https://images.unsplash.com/photo-1530789253388-582c481c54b0?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')`,
        backgroundAttachment: "fixed"
      }}>
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-3xl">
          {/* Main Title */}
          <h1 className="font-heading font-bold text-4xl md:text-6xl mb-6 text-white leading-tight">
            Travel Safely, <br />
            <span className="text-yellow-400">Connect Globally</span>
          </h1>
          
          {/* Featured Quote */}
          <div className="mb-8 p-6 border-l-4 border-yellow-400 bg-black bg-opacity-30 backdrop-blur-sm">
            <p className="text-xl md:text-2xl text-white italic font-heading mb-2">
              "{currentQuote.quote}"
            </p>
            <p className="text-white text-opacity-90">— {currentQuote.author}</p>
          </div>
          
          <p className="text-lg md:text-xl mb-8 text-white text-opacity-90">
            Join our community of travelers sharing safety tips, connecting with fellow adventurers, and exploring the world with confidence.
          </p>
          
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/#destinations">
              <Button className="bg-white text-primary font-bold py-3 px-6 rounded-lg hover:bg-opacity-90 transition duration-300 flex items-center justify-center h-auto">
                <i className="fas fa-map-marker-alt mr-2"></i> Explore Safe Destinations
              </Button>
            </Link>
            <Button className="bg-[#34A853] text-white font-bold py-3 px-6 rounded-lg hover:bg-opacity-90 transition duration-300 flex items-center justify-center h-auto">
              <i className="fas fa-user-plus mr-2"></i> Join SafeConnect
            </Button>
          </div>
          
          {/* Safety Features Preview */}
          <div className="flex flex-wrap mt-12 gap-4">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4 flex items-center space-x-3">
              <div className="p-2 bg-[#EA4335] rounded-full">
                <i className="fas fa-exclamation-triangle text-white"></i>
              </div>
              <span className="text-white">SOS Alerts</span>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4 flex items-center space-x-3">
              <div className="p-2 bg-[#34A853] rounded-full">
                <i className="fas fa-map-marked-alt text-white"></i>
              </div>
              <span className="text-white">Safety Maps</span>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4 flex items-center space-x-3">
              <div className="p-2 bg-primary rounded-full">
                <i className="fas fa-comments text-white"></i>
              </div>
              <span className="text-white">Traveler Chat</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative Wave SVG */}
      <div className="absolute bottom-0 left-0 w-full">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" fill="#ffffff">
          <path d="M0,96L80,80C160,64,320,32,480,32C640,32,800,64,960,69.3C1120,75,1280,53,1360,42.7L1440,32L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"></path>
        </svg>
      </div>
    </section>
  );
}
