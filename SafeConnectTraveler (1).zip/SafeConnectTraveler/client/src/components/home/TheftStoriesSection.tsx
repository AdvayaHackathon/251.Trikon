import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Story } from '@shared/schema';
import { format } from 'date-fns';

export default function TheftStoriesSection() {
  const [, setLocation] = useLocation();
  
  const [destinationFilter, setDestinationFilter] = useState("All Destinations");
  const [incidentTypeFilter, setIncidentTypeFilter] = useState("All Types");
  const [dateRangeFilter, setDateRangeFilter] = useState("All Time");
  
  // Query for stories
  const { data: stories, isLoading } = useQuery({
    queryKey: ['/api/stories'],
  });
  
  // Filter stories based on selected filters
  const filteredStories = stories?.filter((story: Story) => {
    let match = true;
    
    if (destinationFilter !== "All Destinations") {
      // Filter by region/continent
      const continent = destinationFilter.toLowerCase();
      const country = story.country.toLowerCase();
      
      if (continent === "europe" && !["france", "spain", "italy", "germany", "uk"].includes(country)) {
        match = false;
      } else if (continent === "asia" && !["japan", "thailand", "china", "vietnam", "indonesia"].includes(country)) {
        match = false;
      } else if (continent === "north america" && !["usa", "canada", "mexico"].includes(country)) {
        match = false;
      }
    }
    
    if (incidentTypeFilter !== "All Types" && story.incidentType !== incidentTypeFilter) {
      match = false;
    }
    
    if (dateRangeFilter !== "All Time") {
      const storyDate = new Date(story.incidentDate);
      const now = new Date();
      
      if (dateRangeFilter === "Last Month" && (now.getTime() - storyDate.getTime() > 30 * 24 * 60 * 60 * 1000)) {
        match = false;
      } else if (dateRangeFilter === "Last 3 Months" && (now.getTime() - storyDate.getTime() > 90 * 24 * 60 * 60 * 1000)) {
        match = false;
      } else if (dateRangeFilter === "Last 6 Months" && (now.getTime() - storyDate.getTime() > 180 * 24 * 60 * 60 * 1000)) {
        match = false;
      } else if (dateRangeFilter === "Last Year" && (now.getTime() - storyDate.getTime() > 365 * 24 * 60 * 60 * 1000)) {
        match = false;
      }
    }
    
    return match;
  }) || [];
  
  // Display only 2 stories initially
  const displayedStories = filteredStories.slice(0, 2);

  // Get incident type color
  const getIncidentTypeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pickpocketing':
        return 'bg-yellow-100 text-yellow-800';
      case 'scam':
        return 'bg-orange-100 text-orange-800';
      case 'robbery':
        return 'bg-red-100 text-red-800';
      case 'card skimming':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-neutral-100 text-neutral-800';
    }
  };

  return (
    <section id="stories" className="py-16 bg-neutral-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div>
            <h2 className="font-heading font-bold text-3xl mb-2">Theft Story Sharing</h2>
            <p className="text-neutral-600 max-w-2xl">Learn from others' experiences to stay safe during your travels.</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Link href="/share-story">
              <Button className="bg-primary text-white font-medium py-2 px-4 rounded-lg hover:bg-primary-dark transition-colors">
                <i className="fas fa-plus mr-2"></i> Share Your Story
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Story Filter */}
        <div className="bg-white p-4 rounded-lg shadow-sm mb-8">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Destination</label>
              <Select value={destinationFilter} onValueChange={setDestinationFilter}>
                <SelectTrigger className="w-full p-2 bg-neutral-100 rounded-lg border border-neutral-300">
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All Destinations">All Destinations</SelectItem>
                  <SelectItem value="Europe">Europe</SelectItem>
                  <SelectItem value="Asia">Asia</SelectItem>
                  <SelectItem value="North America">North America</SelectItem>
                  <SelectItem value="South America">South America</SelectItem>
                  <SelectItem value="Africa">Africa</SelectItem>
                  <SelectItem value="Oceania">Oceania</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Incident Type</label>
              <Select value={incidentTypeFilter} onValueChange={setIncidentTypeFilter}>
                <SelectTrigger className="w-full p-2 bg-neutral-100 rounded-lg border border-neutral-300">
                  <SelectValue placeholder="Select incident type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All Types">All Types</SelectItem>
                  <SelectItem value="Pickpocketing">Pickpocketing</SelectItem>
                  <SelectItem value="Scam">Scams</SelectItem>
                  <SelectItem value="Robbery">Robbery</SelectItem>
                  <SelectItem value="Card Skimming">Card Skimming</SelectItem>
                  <SelectItem value="Bag Snatching">Bag Snatching</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex-1 min-w-[200px]">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Date Range</label>
              <Select value={dateRangeFilter} onValueChange={setDateRangeFilter}>
                <SelectTrigger className="w-full p-2 bg-neutral-100 rounded-lg border border-neutral-300">
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="All Time">All Time</SelectItem>
                  <SelectItem value="Last Month">Last Month</SelectItem>
                  <SelectItem value="Last 3 Months">Last 3 Months</SelectItem>
                  <SelectItem value="Last 6 Months">Last 6 Months</SelectItem>
                  <SelectItem value="Last Year">Last Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button className="bg-neutral-200 text-neutral-700 h-[42px] px-4 rounded-lg hover:bg-neutral-300 transition-colors">
                <i className="fas fa-filter mr-2"></i> Apply Filters
              </Button>
            </div>
          </div>
        </div>
        
        {/* Stories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {isLoading ? (
            <div className="col-span-2 text-center py-12">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <p className="mt-4 text-neutral-600">Loading stories...</p>
            </div>
          ) : displayedStories.length > 0 ? (
            displayedStories.map((story: Story) => (
              <div key={story.id} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-heading font-semibold text-xl">{story.title}</h3>
                      <div className="flex items-center mt-1 text-sm text-neutral-500">
                        <span><i className="fas fa-map-marker-alt mr-1"></i> {story.location}, {story.country}</span>
                        <span className="mx-2">•</span>
                        <span><i className="far fa-calendar-alt mr-1"></i> {format(new Date(story.incidentDate), 'MMM d, yyyy')}</span>
                      </div>
                    </div>
                    <div className={`${getIncidentTypeColor(story.incidentType)} text-xs font-medium py-1 px-2 rounded`}>
                      {story.incidentType}
                    </div>
                  </div>
                  
                  <p className="text-neutral-600 mb-4">
                    {story.content}
                  </p>
                  
                  <div className="bg-neutral-100 p-4 rounded-lg mb-4">
                    <h4 className="font-medium text-neutral-800 mb-2"><i className="fas fa-lightbulb text-yellow-500 mr-2"></i> Prevention Tips</h4>
                    <ul className="list-disc list-inside text-neutral-600 space-y-1">
                      {story.preventionTips.map((tip: string, index: number) => (
                        <li key={index}>{tip}</li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-full bg-neutral-300 flex items-center justify-center">
                        <i className="fas fa-user text-neutral-500"></i>
                      </div>
                      <span className="text-neutral-600 text-sm">Posted by <span className="font-medium">User {story.userId}</span></span>
                    </div>
                    <div className="flex space-x-4 text-neutral-500">
                      <button className="hover:text-primary transition-colors">
                        <i className="far fa-bookmark"></i>
                      </button>
                      <button className="hover:text-primary transition-colors">
                        <i className="far fa-comment-alt"></i> {story.comments}
                      </button>
                      <button className="hover:text-primary transition-colors">
                        <i className="far fa-thumbs-up"></i> {story.likes}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-2 text-center py-12">
              <p className="text-neutral-600">No stories found matching your filters. Try different criteria.</p>
            </div>
          )}
          
          {/* View More Button */}
          <div className="md:col-span-2 flex justify-center mt-4">
            <Button className="bg-white border border-primary text-primary hover:bg-primary hover:text-white transition-colors duration-300 font-medium rounded-lg px-8 py-3">
              View More Stories
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
