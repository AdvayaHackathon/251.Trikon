export default function FeaturesOverview() {
  const features = [
    {
      icon: "fa-map-marked-alt",
      title: "Safety Maps",
      description: "Interactive maps with safety zones, emergency services, and real-time alerts based on your location.",
      color: "primary"
    },
    {
      icon: "fa-comments",
      title: "Traveler Chat",
      description: "Connect with solo travelers at your destination for tips, meetups, and shared experiences.",
      color: "secondary"
    },
    {
      icon: "fa-exclamation-triangle",
      title: "Emergency SOS",
      description: "One-touch emergency button sends your location to trusted contacts when you need immediate help.",
      color: "accent"
    },
    {
      icon: "fa-shield-alt",
      title: "Theft Prevention",
      description: "Browse and share real-life theft stories to learn how to avoid common scams at your destination.",
      color: "blue-500"
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-heading font-bold text-3xl text-center mb-12">How SafeConnect Protects You</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-neutral-100 rounded-xl p-6 transition-transform hover:scale-105 hover:shadow-md">
              <div className={`bg-${feature.color} bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mb-4`}>
                <i className={`fas ${feature.icon} text-2xl text-${feature.color === 'primary' ? 'primary' : feature.color === 'secondary' ? '[#34A853]' : feature.color === 'accent' ? '[#EA4335]' : 'blue-500'}`}></i>
              </div>
              <h3 className="font-heading font-semibold text-xl mb-2">{feature.title}</h3>
              <p className="text-neutral-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
