import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ChatRoom } from '@shared/schema';

export default function ChatSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("Europe");

  // Get all chat rooms
  const { data: chatRooms, isLoading } = useQuery({
    queryKey: ['/api/chat-rooms'],
  });

  // Filter chat rooms based on search and active category
  const filteredRooms = chatRooms?.filter((room: ChatRoom) => {
    let matchesSearch = true;
    let matchesCategory = true;
    
    if (searchQuery) {
      matchesSearch = 
        room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        room.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        room.description.toLowerCase().includes(searchQuery.toLowerCase());
    }
    
    if (activeCategory !== "All") {
      matchesCategory = room.region === activeCategory;
    }
    
    return matchesSearch && matchesCategory;
  }) || [];

  // Get the currently "active" chat room for display
  const activeRoom = filteredRooms.length > 0 ? filteredRooms[0] : null;

  return (
    <section id="chat" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="font-heading font-bold text-3xl mb-4">Solo Traveler Chat</h2>
          <p className="text-neutral-600">Connect with fellow travelers, ask questions, and share experiences in destination-specific chat rooms.</p>
        </div>
        
        <div className="bg-neutral-100 rounded-xl overflow-hidden shadow-lg">
          <div className="grid grid-cols-1 lg:grid-cols-3">
            {/* Chat Rooms List */}
            <div className="bg-white p-4 border-r border-neutral-200">
              <div className="mb-4">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search chat rooms..."
                    className="w-full py-2 px-4 pr-10 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-500">
                    <i className="fas fa-search"></i>
                  </button>
                </div>
              </div>
              
              {/* Popular Categories */}
              <div className="mb-4">
                <h3 className="font-medium text-neutral-800 mb-2">Popular Categories</h3>
                <div className="flex flex-wrap gap-2">
                  <Button 
                    className={activeCategory === "Europe" ? "bg-primary text-white text-sm py-1 px-3 rounded-full" : "bg-neutral-200 text-neutral-700 text-sm py-1 px-3 rounded-full hover:bg-neutral-300"}
                    onClick={() => setActiveCategory("Europe")}
                    variant="ghost"
                    size="sm"
                  >
                    Europe
                  </Button>
                  <Button 
                    className={activeCategory === "Asia" ? "bg-primary text-white text-sm py-1 px-3 rounded-full" : "bg-neutral-200 text-neutral-700 text-sm py-1 px-3 rounded-full hover:bg-neutral-300"}
                    onClick={() => setActiveCategory("Asia")}
                    variant="ghost"
                    size="sm"
                  >
                    Asia
                  </Button>
                  <Button 
                    className={activeCategory === "Americas" ? "bg-primary text-white text-sm py-1 px-3 rounded-full" : "bg-neutral-200 text-neutral-700 text-sm py-1 px-3 rounded-full hover:bg-neutral-300"}
                    onClick={() => setActiveCategory("Americas")}
                    variant="ghost"
                    size="sm"
                  >
                    Americas
                  </Button>
                  <Button 
                    className={activeCategory === "Global" ? "bg-primary text-white text-sm py-1 px-3 rounded-full" : "bg-neutral-200 text-neutral-700 text-sm py-1 px-3 rounded-full hover:bg-neutral-300"}
                    onClick={() => setActiveCategory("Global")}
                    variant="ghost"
                    size="sm"
                  >
                    Solo Female
                  </Button>
                  <Button 
                    className={activeCategory === "Budget" ? "bg-primary text-white text-sm py-1 px-3 rounded-full" : "bg-neutral-200 text-neutral-700 text-sm py-1 px-3 rounded-full hover:bg-neutral-300"}
                    onClick={() => setActiveCategory("Budget")}
                    variant="ghost"
                    size="sm"
                  >
                    Budget
                  </Button>
                </div>
              </div>
              
              {/* Active Chat Rooms */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-neutral-800">Active Chat Rooms</h3>
                  <Link href="/chat/new">
                    <button className="text-primary text-sm hover:underline">
                      <i className="fas fa-plus-circle mr-1"></i> New
                    </button>
                  </Link>
                </div>
                
                {isLoading ? (
                  <div className="text-center p-4">
                    <div className="inline-block h-6 w-6 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
                    <p className="mt-2 text-sm text-neutral-600">Loading chat rooms...</p>
                  </div>
                ) : filteredRooms.length > 0 ? (
                  filteredRooms.map((room: ChatRoom, index: number) => (
                    <Link key={room.id} href={`/chat/${room.id}`}>
                      <div 
                        className={index === 0 ? "bg-primary bg-opacity-10 p-3 rounded-lg mb-2 cursor-pointer" : "hover:bg-neutral-100 p-3 rounded-lg mb-2 cursor-pointer"}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <h4 className={index === 0 ? "font-medium text-primary" : "font-medium text-neutral-800"}>{room.name}</h4>
                          <span className={index === 0 ? "bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full" : "bg-neutral-200 text-neutral-600 text-xs px-2 py-0.5 rounded-full"}>
                            {index === 0 ? "Active" : `${room.activeUsers} online`}
                          </span>
                        </div>
                        <div className="flex items-center text-sm text-neutral-600 mb-1">
                          <i className={room.region === "Global" ? "fas fa-user-friends mr-1" : room.region === "Europe" ? "fas fa-globe-europe mr-1" : "fas fa-globe-asia mr-1"}></i> {room.location}
                        </div>
                        <p className="text-xs text-neutral-500 truncate">
                          {index === 0 ? "Lisa: Does anyone know a good cafe near the Louvre?" : 
                          index === 1 ? "Mark: I found an amazing street food spot near Khao San Road!" :
                          index === 2 ? "Emma: Anyone in Rome this weekend? Looking for travel buddies." :
                          "Ryan: How's the Tokyo Metro during rush hour?"}
                        </p>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-center p-4">
                    <p className="text-sm text-neutral-500">No chat rooms found matching your search.</p>
                  </div>
                )}
                
                <Link href="/chat">
                  <button className="w-full text-center py-2 text-sm text-primary hover:underline mt-2">
                    View All Chat Rooms
                  </button>
                </Link>
              </div>
            </div>
            
            {/* Chat Area */}
            <div className="lg:col-span-2 flex flex-col h-[500px]">
              {activeRoom ? (
                <>
                  {/* Chat Header */}
                  <div className="bg-white p-4 border-b border-neutral-200 flex justify-between items-center">
                    <div>
                      <h3 className="font-heading font-semibold text-lg">{activeRoom.name}</h3>
                      <div className="text-sm text-neutral-500 flex items-center">
                        <span><i className="fas fa-map-marker-alt mr-1"></i> {activeRoom.location}</span>
                        <span className="mx-2">•</span>
                        <span><i className="fas fa-users mr-1"></i> {activeRoom.activeUsers} travelers online</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <button className="text-neutral-500 hover:text-primary">
                        <i className="fas fa-info-circle"></i>
                      </button>
                      <button className="text-neutral-500 hover:text-primary">
                        <i className="fas fa-user-plus"></i>
                      </button>
                      <button className="text-neutral-500 hover:text-primary">
                        <i className="fas fa-ellipsis-v"></i>
                      </button>
                    </div>
                  </div>
                  
                  {/* Chat Messages */}
                  <div className="flex-1 p-4 overflow-y-auto bg-neutral-50" style={{ height: '350px' }}>
                    {/* Date Separator */}
                    <div className="text-center my-3">
                      <span className="bg-neutral-200 text-neutral-600 text-xs px-2 py-1 rounded-full">
                        Today
                      </span>
                    </div>
                    
                    {/* Their Message */}
                    <div className="flex mb-4">
                      <div className="w-8 h-8 rounded-full bg-neutral-300 flex-shrink-0 mr-2">
                        <img 
                          src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                          alt="User avatar" 
                          className="w-full h-full rounded-full"
                        />
                      </div>
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="font-medium text-sm">Lisa</span>
                          <span className="text-xs text-neutral-500 ml-2">10:24 AM</span>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          <p className="text-neutral-800">Hey everyone! Does anyone know a good cafe near the Louvre? Preferably one that's not super touristy.</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Their Message */}
                    <div className="flex mb-4">
                      <div className="w-8 h-8 rounded-full bg-neutral-300 flex-shrink-0 mr-2">
                        <img 
                          src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                          alt="User avatar" 
                          className="w-full h-full rounded-full"
                        />
                      </div>
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="font-medium text-sm">David</span>
                          <span className="text-xs text-neutral-500 ml-2">10:27 AM</span>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          <p className="text-neutral-800">Try Café Kitsuné in the Palais Royal gardens. Great coffee and not too crowded usually.</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Their Message with Image */}
                    <div className="flex mb-4">
                      <div className="w-8 h-8 rounded-full bg-neutral-300 flex-shrink-0 mr-2">
                        <img 
                          src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                          alt="User avatar" 
                          className="w-full h-full rounded-full"
                        />
                      </div>
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="font-medium text-sm">David</span>
                          <span className="text-xs text-neutral-500 ml-2">10:28 AM</span>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          <img 
                            src="https://images.unsplash.com/photo-1525648199074-cee30ba79a4a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                            alt="Cafe in Paris" 
                            className="w-full h-40 object-cover rounded-lg mb-2"
                          />
                          <p className="text-neutral-800">This is what it looks like. Very charming place!</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* My Message */}
                    <div className="flex flex-row-reverse mb-4">
                      <div className="w-8 h-8 rounded-full bg-primary flex-shrink-0 ml-2 flex items-center justify-center text-white font-medium">
                        Y
                      </div>
                      <div>
                        <div className="flex flex-row-reverse items-center mb-1">
                          <span className="text-xs text-neutral-500 mr-2">10:30 AM</span>
                          <span className="font-medium text-sm">You</span>
                        </div>
                        <div className="bg-primary text-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          <p>Thank you so much, David! That looks perfect. How crowded does it get in the afternoon?</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* System Message */}
                    <div className="text-center my-3">
                      <span className="bg-neutral-200 text-neutral-600 text-xs px-2 py-1 rounded-full">
                        Carlos joined the chat
                      </span>
                    </div>
                    
                    {/* Their Message */}
                    <div className="flex mb-4">
                      <div className="w-8 h-8 rounded-full bg-neutral-300 flex-shrink-0 mr-2">
                        <img 
                          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                          alt="User avatar" 
                          className="w-full h-full rounded-full"
                        />
                      </div>
                      <div>
                        <div className="flex items-center mb-1">
                          <span className="font-medium text-sm">Carlos</span>
                          <span className="text-xs text-neutral-500 ml-2">10:35 AM</span>
                        </div>
                        <div className="bg-white p-3 rounded-lg shadow-sm max-w-xs md:max-w-md">
                          <p className="text-neutral-800">Hey everyone! I'm heading to the Eiffel Tower area tonight. Anyone want to join for dinner?</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Message Input */}
                  <div className="p-3 bg-white border-t border-neutral-200">
                    <div className="flex items-center">
                      <button className="p-2 text-neutral-500 hover:text-primary">
                        <i className="far fa-image"></i>
                      </button>
                      <button className="p-2 text-neutral-500 hover:text-primary">
                        <i className="far fa-smile"></i>
                      </button>
                      <Input 
                        type="text" 
                        placeholder="Type your message..." 
                        className="flex-1 border border-neutral-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary mx-2"
                      />
                      <Button className="bg-primary text-white p-2 rounded-lg hover:bg-primary-dark transition-colors">
                        <i className="fas fa-paper-plane"></i>
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full bg-neutral-50">
                  <div className="text-6xl text-neutral-300 mb-4">
                    <i className="fas fa-comments"></i>
                  </div>
                  <h3 className="text-xl font-medium text-neutral-600 mb-2">No Chat Selected</h3>
                  <p className="text-neutral-500 max-w-md text-center mb-6">
                    Select a chat room from the sidebar or join a new chat to start connecting with fellow travelers.
                  </p>
                  <Link href="/chat/new">
                    <Button className="bg-primary text-white font-medium py-2 px-4 rounded-lg">
                      <i className="fas fa-plus mr-2"></i> Create New Chat Room
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
