import { Button } from "@/components/ui/button";

export default function CtaSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-primary to-blue-700 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="font-heading font-bold text-3xl md:text-4xl mb-4">Ready to Travel with Confidence?</h2>
        <p className="text-white text-opacity-90 max-w-2xl mx-auto mb-8 text-lg">
          Join thousands of travelers who use SafeConnect to explore the world safely.
        </p>
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Button className="bg-white text-primary font-bold py-3 px-8 rounded-lg hover:bg-opacity-90 transition duration-300 h-auto">
            Create Free Account
          </Button>
          <Button variant="outline" className="bg-transparent border-2 border-white text-white font-bold py-3 px-8 rounded-lg hover:bg-white hover:bg-opacity-10 transition duration-300 h-auto">
            Learn More
          </Button>
        </div>
      </div>
    </section>
  );
}
