import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onSOSClick: () => void;
}

export default function Header({ onSOSClick }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-1">
          <Link href="/">
            <div className="text-primary font-heading font-bold text-2xl cursor-pointer">
              Safe<span className="text-[#34A853]">Connect</span>
            </div>
          </Link>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/#destinations">
            <a className="font-medium hover:text-primary transition duration-200">Destinations</a>
          </Link>
          <Link href="/#safety-map">
            <a className="font-medium hover:text-primary transition duration-200">Safety Map</a>
          </Link>
          <Link href="/#stories">
            <a className="font-medium hover:text-primary transition duration-200">Theft Stories</a>
          </Link>
          <Link href="/#chat">
            <a className="font-medium hover:text-primary transition duration-200">Solo Traveler Chat</a>
          </Link>
          <Button 
            onClick={onSOSClick}
            className="sos-button bg-[#EA4335] hover:bg-red-700 text-white font-bold py-2 px-4 rounded-full transition duration-300 flex items-center"
          >
            <i className="fas fa-exclamation-triangle mr-2"></i> SOS
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center space-x-1 bg-neutral-200 hover:bg-neutral-300 rounded-full px-3 py-1 transition border-none">
                <i className="fas fa-user-circle text-neutral-600"></i>
                <span className="font-medium">Account</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <Link href="/profile">
                <DropdownMenuItem className="cursor-pointer">
                  <i className="fas fa-user mr-2"></i> Profile
                </DropdownMenuItem>
              </Link>
              <DropdownMenuItem className="cursor-pointer">
                <i className="fas fa-cog mr-2"></i> Settings
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer">
                <i className="fas fa-sign-out-alt mr-2"></i> Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-neutral-800 focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <i className="fas fa-bars text-2xl"></i>
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg border-t border-gray-100 py-4">
          <div className="container mx-auto px-4 flex flex-col space-y-4">
            <Link href="/#destinations">
              <a className="font-medium hover:text-primary transition duration-200 py-2">Destinations</a>
            </Link>
            <Link href="/#safety-map">
              <a className="font-medium hover:text-primary transition duration-200 py-2">Safety Map</a>
            </Link>
            <Link href="/#stories">
              <a className="font-medium hover:text-primary transition duration-200 py-2">Theft Stories</a>
            </Link>
            <Link href="/#chat">
              <a className="font-medium hover:text-primary transition duration-200 py-2">Solo Traveler Chat</a>
            </Link>
            <Link href="/profile">
              <a className="font-medium hover:text-primary transition duration-200 py-2">Profile</a>
            </Link>
          </div>
        </div>
      )}
      
      {/* Mobile SOS Button (Always visible on mobile) */}
      <div className="fixed bottom-24 right-4 md:hidden z-50">
        <Button 
          onClick={onSOSClick}
          className="sos-button bg-[#EA4335] hover:bg-red-700 text-white shadow-lg font-bold h-14 w-14 rounded-full flex items-center justify-center"
        >
          <i className="fas fa-exclamation-triangle text-xl"></i>
        </Button>
      </div>
    </header>
  );
}
