import { Link, useLocation } from "wouter";

interface MobileNavProps {
  onSOSClick: () => void;
}

export default function MobileNav({ onSOSClick }: MobileNavProps) {
  const [location] = useLocation();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-lg z-40 border-t border-neutral-200">
      <div className="flex justify-around">
        <Link href="/">
          <a className={`flex flex-col items-center py-2 px-3 ${location === '/' ? 'text-primary' : 'text-neutral-600 hover:text-primary'}`}>
            <i className="fas fa-home text-lg"></i>
            <span className="text-xs mt-1">Home</span>
          </a>
        </Link>
        <Link href="/#safety-map">
          <a className="flex flex-col items-center py-2 px-3 text-neutral-600 hover:text-primary">
            <i className="fas fa-map-marked-alt text-lg"></i>
            <span className="text-xs mt-1">Map</span>
          </a>
        </Link>
        <Link href="/#stories">
          <a className="flex flex-col items-center py-2 px-3 text-neutral-600 hover:text-primary">
            <i className="fas fa-book text-lg"></i>
            <span className="text-xs mt-1">Stories</span>
          </a>
        </Link>
        <Link href="/#chat">
          <a className="flex flex-col items-center py-2 px-3 text-neutral-600 hover:text-primary">
            <i className="fas fa-comments text-lg"></i>
            <span className="text-xs mt-1">Chat</span>
          </a>
        </Link>
        <Link href="/profile">
          <a className={`flex flex-col items-center py-2 px-3 ${location === '/profile' ? 'text-primary' : 'text-neutral-600 hover:text-primary'}`}>
            <i className="fas fa-user-circle text-lg"></i>
            <span className="text-xs mt-1">Profile</span>
          </a>
        </Link>
      </div>
    </div>
  );
}
