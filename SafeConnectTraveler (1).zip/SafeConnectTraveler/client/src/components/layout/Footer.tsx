import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="text-white font-heading font-bold text-2xl mb-4">
              Safe<span className="text-[#34A853]">Connect</span>
            </div>
            <p className="text-neutral-400 mb-4">
              Travel safely, connect globally, and explore with confidence.
            </p>
            <div className="flex space-x-4 text-neutral-400">
              <a href="#" className="hover:text-white transition-colors"><i className="fab fa-facebook-f"></i></a>
              <a href="#" className="hover:text-white transition-colors"><i className="fab fa-twitter"></i></a>
              <a href="#" className="hover:text-white transition-colors"><i className="fab fa-instagram"></i></a>
              <a href="#" className="hover:text-white transition-colors"><i className="fab fa-youtube"></i></a>
            </div>
          </div>
          
          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Features</h3>
            <ul className="space-y-2 text-neutral-400">
              <li><Link href="/#safety-map"><a className="hover:text-white transition-colors">Safety Map</a></Link></li>
              <li><Link href="/#stories"><a className="hover:text-white transition-colors">Theft Stories</a></Link></li>
              <li><Link href="/#chat"><a className="hover:text-white transition-colors">Solo Traveler Chat</a></Link></li>
              <li><a href="#" className="hover:text-white transition-colors">Emergency SOS</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Travel Alerts</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-2 text-neutral-400">
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Our Mission</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading font-semibold text-lg mb-4">Support</h3>
            <ul className="space-y-2 text-neutral-400">
              <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Safety Resources</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 pt-6 text-center text-neutral-500 text-sm">
          <p>&copy; {new Date().getFullYear()} SafeConnect. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
