import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add custom styles for Montserrat and Open Sans fonts
const style = document.createElement('style');
style.textContent = `
  :root {
    --primary: 217 89% 61%;
    --primary-foreground: 0 0% 100%;
    --secondary: 138 55% 44%;
    --secondary-foreground: 0 0% 100%;
    --accent: 4 83% 56%;
    --accent-foreground: 0 0% 100%;
  }

  body {
    font-family: 'Open Sans', sans-serif;
  }

  h1, h2, h3, h4, h5, h6,
  .font-heading {
    font-family: 'Montserrat', sans-serif;
  }
`;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
