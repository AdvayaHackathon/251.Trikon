import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNav from "@/components/layout/MobileNav";
import Home from "@/pages/Home";
import ChatRoom from "@/pages/ChatRoom";
import Destination from "@/pages/Destination";
import StoryDetail from "@/pages/StoryDetail";
import ShareStory from "@/pages/ShareStory";
import Profile from "@/pages/Profile";
import { useState, useEffect } from "react";
import { WebSocketProvider } from "./lib/websocket";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/chat/:id" component={ChatRoom} />
      <Route path="/destination/:id" component={Destination} />
      <Route path="/story/:id" component={StoryDetail} />
      <Route path="/share-story" component={ShareStory} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [sosActive, setSosActive] = useState(false);

  // Handle SOS button activation
  const triggerSOS = () => {
    if (window.confirm('This will send your current location to your emergency contacts. Continue?')) {
      setSosActive(true);
      setTimeout(() => {
        alert('SOS activated! Your location has been sent to your emergency contacts.');
        setSosActive(false);
      }, 1000);
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <WebSocketProvider>
        <div className="flex flex-col min-h-screen">
          <Header onSOSClick={triggerSOS} />
          <main className="flex-grow">
            <Router />
          </main>
          <Footer />
          <MobileNav onSOSClick={triggerSOS} />
        </div>
        <Toaster />
      </WebSocketProvider>
    </QueryClientProvider>
  );
}

export default App;
