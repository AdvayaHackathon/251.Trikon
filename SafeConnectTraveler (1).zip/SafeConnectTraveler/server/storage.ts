import { 
  users, type User, type InsertUser,
  destinations, type Destination, type InsertDestination,
  stories, type Story, type InsertStory,
  chatRooms, type ChatRoom, type InsertChatRoom,
  chatMessages, type ChatMessage, type InsertChatMessage,
  safetyAlerts, type SafetyAlert, type InsertSafetyAlert,
  emergencyServices, type EmergencyService, type InsertEmergencyService
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  
  // Destination methods
  getDestination(id: number): Promise<Destination | undefined>;
  getAllDestinations(): Promise<Destination[]>;
  getDestinationsByCountry(country: string): Promise<Destination[]>;
  createDestination(destination: InsertDestination): Promise<Destination>;
  updateDestination(id: number, data: Partial<InsertDestination>): Promise<Destination | undefined>;
  
  // Story methods
  getStory(id: number): Promise<Story | undefined>;
  getAllStories(): Promise<Story[]>;
  getStoriesByCountry(country: string): Promise<Story[]>;
  getStoriesByIncidentType(type: string): Promise<Story[]>;
  getStoriesByUser(userId: number): Promise<Story[]>;
  createStory(story: InsertStory): Promise<Story>;
  updateStory(id: number, data: Partial<InsertStory>): Promise<Story | undefined>;
  
  // Chat Room methods
  getChatRoom(id: number): Promise<ChatRoom | undefined>;
  getAllChatRooms(): Promise<ChatRoom[]>;
  getChatRoomsByRegion(region: string): Promise<ChatRoom[]>;
  createChatRoom(room: InsertChatRoom): Promise<ChatRoom>;
  updateChatRoom(id: number, data: Partial<InsertChatRoom>): Promise<ChatRoom | undefined>;
  updateChatRoomActiveUsers(id: number, count: number): Promise<void>;
  
  // Chat Message methods
  getChatMessage(id: number): Promise<ChatMessage | undefined>;
  getChatMessagesByRoom(roomId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Safety Alert methods
  getSafetyAlert(id: number): Promise<SafetyAlert | undefined>;
  getAllSafetyAlerts(): Promise<SafetyAlert[]>;
  getSafetyAlertsByLocation(location: string): Promise<SafetyAlert[]>;
  createSafetyAlert(alert: InsertSafetyAlert): Promise<SafetyAlert>;
  
  // Emergency Service methods
  getEmergencyService(id: number): Promise<EmergencyService | undefined>;
  getAllEmergencyServices(): Promise<EmergencyService[]>;
  getEmergencyServicesByLocation(country: string, city?: string): Promise<EmergencyService[]>;
  createEmergencyService(service: InsertEmergencyService): Promise<EmergencyService>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private destinations: Map<number, Destination>;
  private stories: Map<number, Story>;
  private chatRooms: Map<number, ChatRoom>;
  private chatMessages: Map<number, ChatMessage>;
  private safetyAlerts: Map<number, SafetyAlert>;
  private emergencyServices: Map<number, EmergencyService>;
  
  private currentUserId: number;
  private currentDestinationId: number;
  private currentStoryId: number;
  private currentChatRoomId: number;
  private currentChatMessageId: number;
  private currentSafetyAlertId: number;
  private currentEmergencyServiceId: number;

  constructor() {
    this.users = new Map();
    this.destinations = new Map();
    this.stories = new Map();
    this.chatRooms = new Map();
    this.chatMessages = new Map();
    this.safetyAlerts = new Map();
    this.emergencyServices = new Map();
    
    this.currentUserId = 1;
    this.currentDestinationId = 1;
    this.currentStoryId = 1;
    this.currentChatRoomId = 1;
    this.currentChatMessageId = 1;
    this.currentSafetyAlertId = 1;
    this.currentEmergencyServiceId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Sample destinations
    const sampleDestinations = [
      {
        name: "Paris",
        country: "France",
        safetyScore: 4.8,
        safetyStatus: "Safe for Solo Travelers",
        description: "Experience the city of lights with confidence. Connect with 245+ fellow travelers currently in Paris.",
        imageUrl: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeTravelers: 245
      },
      {
        name: "Bangkok",
        country: "Thailand",
        safetyScore: 3.7,
        safetyStatus: "Moderate Caution Advised",
        description: "Vibrant culture and amazing food, but stay alert in tourist areas. Connect with 180+ travelers.",
        imageUrl: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeTravelers: 180
      },
      {
        name: "Tokyo",
        country: "Japan",
        safetyScore: 4.9,
        safetyStatus: "Very Safe for All Travelers",
        description: "One of the safest major cities globally. Connect with 310+ travelers exploring Tokyo's unique culture.",
        imageUrl: "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeTravelers: 310
      },
      {
        name: "Barcelona",
        country: "Spain",
        safetyScore: 3.9,
        safetyStatus: "Generally Safe, Watch for Pickpockets",
        description: "Beautiful architecture and beaches, but be vigilant in tourist areas. Connect with 200+ travelers.",
        imageUrl: "https://images.unsplash.com/photo-1539037116277-4db20889f2d4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeTravelers: 200
      },
      {
        name: "New York City",
        country: "USA",
        safetyScore: 4.2,
        safetyStatus: "Safe with Normal Precautions",
        description: "The city that never sleeps offers endless exploration. Stay connected with 320+ fellow travelers.",
        imageUrl: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeTravelers: 320
      },
      {
        name: "Rome",
        country: "Italy",
        safetyScore: 4.1,
        safetyStatus: "Generally Safe for Travelers",
        description: "Ancient history meets modern city life. Connect with 175+ travelers exploring Rome.",
        imageUrl: "https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeTravelers: 175
      }
    ];

    sampleDestinations.forEach(dest => {
      this.createDestination({
        ...dest,
        createdAt: new Date()
      } as InsertDestination);
    });

    // Sample chat rooms
    const sampleChatRooms = [
      {
        name: "Paris Explorers",
        description: "Chat with fellow travelers exploring Paris",
        location: "Paris, France",
        region: "Europe",
        imageUrl: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeUsers: 24
      },
      {
        name: "Bangkok Adventures",
        description: "Connect with travelers in Bangkok",
        location: "Bangkok, Thailand",
        region: "Asia",
        imageUrl: "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeUsers: 12
      },
      {
        name: "Solo Female Travelers",
        description: "A safe space for solo female travelers to connect worldwide",
        location: "Global",
        region: "Global",
        imageUrl: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeUsers: 38
      },
      {
        name: "Tokyo Discoveries",
        description: "Share tips and experiences in Tokyo",
        location: "Tokyo, Japan",
        region: "Asia",
        imageUrl: "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        activeUsers: 17
      }
    ];

    sampleChatRooms.forEach(room => {
      this.createChatRoom({
        ...room,
        createdAt: new Date()
      } as InsertChatRoom);
    });

    // Sample stories
    const sampleStories = [
      {
        title: "Pickpocketing in Barcelona Metro",
        content: "While riding the crowded L1 metro line during rush hour, I felt someone bump into me. Later, I discovered my wallet was missing from my back pocket. I immediately reported it to the metro security.",
        incidentType: "Pickpocketing",
        location: "Barcelona",
        country: "Spain",
        preventionTips: [
          "Keep valuables in front pockets or inside bags",
          "Use anti-theft bags with zippers facing your body",
          "Be extra vigilant in crowded metros, especially L1, L3 lines",
          "Consider money belts for important documents"
        ],
        incidentDate: new Date("2023-05-15"),
        userId: 1,
        likes: 34,
        comments: 12
      },
      {
        title: "Taxi Scam in Bangkok",
        content: "A taxi driver at the airport refused to use the meter and quoted an inflated price. When I insisted on the meter, he claimed it was broken. I later learned this is a common scam targeting tourists arriving at Suvarnabhumi Airport.",
        incidentType: "Scam",
        location: "Bangkok",
        country: "Thailand",
        preventionTips: [
          "Only use taxis from the official queue at the airport",
          "Always insist on using the meter",
          "Consider using ride-hailing apps like Grab",
          "Note the driver's ID and car number when entering"
        ],
        incidentDate: new Date("2023-06-03"),
        userId: 1,
        likes: 27,
        comments: 8
      }
    ];

    // Create a test user
    const testUser = this.createUser({
      username: "testuser",
      password: "password123",
      email: "test@example.com",
      fullName: "Test User",
      profilePic: "",
      emergencyContacts: []
    });

    sampleStories.forEach(story => {
      this.createStory({
        ...story,
        userId: testUser.id,
        createdAt: new Date()
      } as InsertStory);
    });

    // Sample safety alerts
    const sampleSafetyAlerts = [
      {
        title: "Protest Alert",
        content: "Peaceful protest near Central Square. Expect traffic delays. ⚠️",
        alertType: "Civil Unrest",
        severity: "Medium",
        location: "Paris, France",
        latitude: "48.8566",
        longitude: "2.3522",
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours from now
      },
      {
        title: "Pickpocket Warning",
        content: "Increased theft reported at Market Street. Secure belongings. 👝",
        alertType: "Crime",
        severity: "Medium",
        location: "Barcelona, Spain",
        latitude: "41.3851",
        longitude: "2.1734",
        expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000) // 48 hours from now
      }
    ];

    sampleSafetyAlerts.forEach(alert => {
      this.createSafetyAlert({
        ...alert,
        createdAt: new Date()
      } as InsertSafetyAlert);
    });

    // Sample emergency services
    const sampleEmergencyServices = [
      {
        name: "Hôpital Saint-Louis",
        serviceType: "Hospital",
        phone: "+33 1 42 49 49 49",
        address: "1 Avenue Claude Vellefaux, 75010 Paris",
        latitude: "48.8752",
        longitude: "2.3692",
        country: "France",
        city: "Paris"
      },
      {
        name: "Commissariat de Police du 1er arrondissement",
        serviceType: "Police",
        phone: "+33 1 40 20 20 20",
        address: "45 Place du Marché Saint-Honoré, 75001 Paris",
        latitude: "48.8675",
        longitude: "2.3314",
        country: "France",
        city: "Paris"
      },
      {
        name: "U.S. Embassy in Paris",
        serviceType: "Embassy",
        phone: "+33 1 43 12 22 22",
        address: "2 Avenue Gabriel, 75008 Paris",
        latitude: "48.8702",
        longitude: "2.3140",
        country: "France",
        city: "Paris"
      }
    ];

    sampleEmergencyServices.forEach(service => {
      this.createEmergencyService(service as InsertEmergencyService);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const newUser: User = { ...user, id, createdAt: new Date() };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Destination methods
  async getDestination(id: number): Promise<Destination | undefined> {
    return this.destinations.get(id);
  }

  async getAllDestinations(): Promise<Destination[]> {
    return Array.from(this.destinations.values());
  }

  async getDestinationsByCountry(country: string): Promise<Destination[]> {
    return Array.from(this.destinations.values()).filter(
      (dest) => dest.country.toLowerCase() === country.toLowerCase()
    );
  }

  async createDestination(destination: InsertDestination): Promise<Destination> {
    const id = this.currentDestinationId++;
    const newDestination: Destination = { ...destination, id };
    this.destinations.set(id, newDestination);
    return newDestination;
  }

  async updateDestination(id: number, data: Partial<InsertDestination>): Promise<Destination | undefined> {
    const destination = await this.getDestination(id);
    if (!destination) return undefined;
    
    const updatedDestination = { ...destination, ...data };
    this.destinations.set(id, updatedDestination);
    return updatedDestination;
  }

  // Story methods
  async getStory(id: number): Promise<Story | undefined> {
    return this.stories.get(id);
  }

  async getAllStories(): Promise<Story[]> {
    return Array.from(this.stories.values());
  }

  async getStoriesByCountry(country: string): Promise<Story[]> {
    return Array.from(this.stories.values()).filter(
      (story) => story.country.toLowerCase() === country.toLowerCase()
    );
  }

  async getStoriesByIncidentType(type: string): Promise<Story[]> {
    return Array.from(this.stories.values()).filter(
      (story) => story.incidentType.toLowerCase() === type.toLowerCase()
    );
  }

  async getStoriesByUser(userId: number): Promise<Story[]> {
    return Array.from(this.stories.values()).filter(
      (story) => story.userId === userId
    );
  }

  async createStory(story: InsertStory): Promise<Story> {
    const id = this.currentStoryId++;
    const newStory: Story = { ...story, id, likes: 0, comments: 0, createdAt: new Date() };
    this.stories.set(id, newStory);
    return newStory;
  }

  async updateStory(id: number, data: Partial<InsertStory>): Promise<Story | undefined> {
    const story = await this.getStory(id);
    if (!story) return undefined;
    
    const updatedStory = { ...story, ...data };
    this.stories.set(id, updatedStory);
    return updatedStory;
  }

  // Chat Room methods
  async getChatRoom(id: number): Promise<ChatRoom | undefined> {
    return this.chatRooms.get(id);
  }

  async getAllChatRooms(): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values());
  }

  async getChatRoomsByRegion(region: string): Promise<ChatRoom[]> {
    return Array.from(this.chatRooms.values()).filter(
      (room) => room.region.toLowerCase() === region.toLowerCase()
    );
  }

  async createChatRoom(room: InsertChatRoom): Promise<ChatRoom> {
    const id = this.currentChatRoomId++;
    const newRoom: ChatRoom = { ...room, id, activeUsers: room.activeUsers || 0, createdAt: new Date() };
    this.chatRooms.set(id, newRoom);
    return newRoom;
  }

  async updateChatRoom(id: number, data: Partial<InsertChatRoom>): Promise<ChatRoom | undefined> {
    const room = await this.getChatRoom(id);
    if (!room) return undefined;
    
    const updatedRoom = { ...room, ...data };
    this.chatRooms.set(id, updatedRoom);
    return updatedRoom;
  }

  async updateChatRoomActiveUsers(id: number, count: number): Promise<void> {
    const room = await this.getChatRoom(id);
    if (!room) return;
    
    room.activeUsers = count;
    this.chatRooms.set(id, room);
  }

  // Chat Message methods
  async getChatMessage(id: number): Promise<ChatMessage | undefined> {
    return this.chatMessages.get(id);
  }

  async getChatMessagesByRoom(roomId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).filter(
      (message) => message.roomId === roomId
    );
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = this.currentChatMessageId++;
    const newMessage: ChatMessage = { ...message, id, createdAt: new Date() };
    this.chatMessages.set(id, newMessage);
    return newMessage;
  }

  // Safety Alert methods
  async getSafetyAlert(id: number): Promise<SafetyAlert | undefined> {
    return this.safetyAlerts.get(id);
  }

  async getAllSafetyAlerts(): Promise<SafetyAlert[]> {
    return Array.from(this.safetyAlerts.values());
  }

  async getSafetyAlertsByLocation(location: string): Promise<SafetyAlert[]> {
    return Array.from(this.safetyAlerts.values()).filter(
      (alert) => alert.location.toLowerCase().includes(location.toLowerCase())
    );
  }

  async createSafetyAlert(alert: InsertSafetyAlert): Promise<SafetyAlert> {
    const id = this.currentSafetyAlertId++;
    const newAlert: SafetyAlert = { ...alert, id, createdAt: new Date() };
    this.safetyAlerts.set(id, newAlert);
    return newAlert;
  }

  // Emergency Service methods
  async getEmergencyService(id: number): Promise<EmergencyService | undefined> {
    return this.emergencyServices.get(id);
  }

  async getAllEmergencyServices(): Promise<EmergencyService[]> {
    return Array.from(this.emergencyServices.values());
  }

  async getEmergencyServicesByLocation(country: string, city?: string): Promise<EmergencyService[]> {
    return Array.from(this.emergencyServices.values()).filter(
      (service) => {
        if (city) {
          return service.country.toLowerCase() === country.toLowerCase() && 
                 service.city.toLowerCase() === city.toLowerCase();
        }
        return service.country.toLowerCase() === country.toLowerCase();
      }
    );
  }

  async createEmergencyService(service: InsertEmergencyService): Promise<EmergencyService> {
    const id = this.currentEmergencyServiceId++;
    const newService: EmergencyService = { ...service, id };
    this.emergencyServices.set(id, newService);
    return newService;
  }
}

import { DatabaseStorage } from "./database-storage";

// Comment out the in-memory storage and use the database storage instead
// export const storage = new MemStorage();
export const storage = new DatabaseStorage();
