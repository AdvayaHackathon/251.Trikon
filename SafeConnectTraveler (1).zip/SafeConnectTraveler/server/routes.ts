import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WebSocketServer, WebSocket } from "ws";
import { 
  insertUserSchema, 
  insertStorySchema, 
  insertChatRoomSchema, 
  insertChatMessageSchema,
  insertSafetyAlertSchema
} from "@shared/schema";
import { z } from "zod";
import { getSafetyScoreData, getSafetyScoreForLocation } from './data/safetyScores';

type ClientMessage = {
  type: string;
  roomId?: number;
  userId?: number;
  content?: string;
  imageUrl?: string;
};

type ServerMessage = {
  type: string;
  roomId?: number;
  userId?: number;
  username?: string;
  content?: string;
  imageUrl?: string;
  timestamp?: string;
  userCount?: number;
};

// WebSocket clients and their rooms
const clients = new Map<WebSocket, { userId: number, roomId: number | null }>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Setup WebSocket server for chat functionality
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // WebSocket connection handling
  wss.on('connection', (ws: WebSocket) => {
    // Default state for new connections
    clients.set(ws, { userId: 0, roomId: null });
    
    ws.on('message', async (message: string) => {
      try {
        const parsedMessage: ClientMessage = JSON.parse(message);
        
        switch (parsedMessage.type) {
          case 'join':
            await handleJoinRoom(ws, parsedMessage);
            break;
            
          case 'leave':
            await handleLeaveRoom(ws);
            break;
            
          case 'message':
            await handleChatMessage(ws, parsedMessage);
            break;
            
          default:
            console.log('Unknown message type:', parsedMessage.type);
        }
      } catch (err) {
        console.error('Error processing WebSocket message:', err);
      }
    });
    
    ws.on('close', async () => {
      await handleLeaveRoom(ws);
      clients.delete(ws);
    });
  });

  // Handle joining a chat room
  async function handleJoinRoom(ws: WebSocket, message: ClientMessage) {
    if (!message.roomId || !message.userId) return;
    
    const user = await storage.getUser(message.userId);
    const room = await storage.getChatRoom(message.roomId);
    
    if (!user || !room) return;
    
    // Update client information
    clients.set(ws, { userId: message.userId, roomId: message.roomId });
    
    // Count users in this room
    const usersInRoom = countUsersInRoom(message.roomId);
    
    // Update room active users count
    await storage.updateChatRoomActiveUsers(message.roomId, usersInRoom);
    
    // Notify all clients in the room that someone joined
    broadcastToRoom(message.roomId, {
      type: 'user-joined',
      roomId: message.roomId,
      userId: message.userId,
      username: user.username,
      timestamp: new Date().toISOString(),
      userCount: usersInRoom
    });
    
    // Send recent messages to the newly joined user
    const recentMessages = await storage.getChatMessagesByRoom(message.roomId);
    
    ws.send(JSON.stringify({
      type: 'room-history',
      roomId: message.roomId,
      messages: await Promise.all(recentMessages.map(async msg => {
        const msgUser = await storage.getUser(msg.userId);
        return {
          id: msg.id,
          userId: msg.userId,
          username: msgUser?.username || 'Unknown',
          content: msg.content,
          imageUrl: msg.imageUrl,
          timestamp: msg.createdAt.toISOString()
        };
      }))
    }));
  }

  // Handle leaving a chat room
  async function handleLeaveRoom(ws: WebSocket) {
    const client = clients.get(ws);
    if (!client || client.roomId === null) return;
    
    const { userId, roomId } = client;
    
    // Update client information
    clients.set(ws, { ...client, roomId: null });
    
    // Count remaining users in the room
    const usersInRoom = countUsersInRoom(roomId);
    
    // Update room active users count
    await storage.updateChatRoomActiveUsers(roomId, usersInRoom);
    
    // Notify all clients in the room that someone left
    broadcastToRoom(roomId, {
      type: 'user-left',
      roomId,
      userId,
      timestamp: new Date().toISOString(),
      userCount: usersInRoom
    });
  }

  // Handle chat messages
  async function handleChatMessage(ws: WebSocket, message: ClientMessage) {
    const client = clients.get(ws);
    if (!client || client.roomId === null || !message.content) return;
    
    const { userId, roomId } = client;
    
    // Store message in database
    const chatMessage = await storage.createChatMessage({
      roomId,
      userId,
      content: message.content,
      imageUrl: message.imageUrl
    });
    
    // Get user data for the sender
    const user = await storage.getUser(userId);
    if (!user) return;
    
    // Broadcast message to all clients in the room
    broadcastToRoom(roomId, {
      type: 'message',
      roomId,
      userId,
      username: user.username,
      content: message.content,
      imageUrl: message.imageUrl,
      timestamp: chatMessage.createdAt.toISOString()
    });
  }

  // Count users in a specific room
  function countUsersInRoom(roomId: number): number {
    let count = 0;
    for (const client of clients.values()) {
      if (client.roomId === roomId) {
        count++;
      }
    }
    return count;
  }

  // Broadcast a message to all clients in a room
  function broadcastToRoom(roomId: number, message: ServerMessage) {
    for (const [client, data] of clients.entries()) {
      if (data.roomId === roomId && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    }
  }

  // API Routes
  // GET destinations
  app.get('/api/destinations', async (_req: Request, res: Response) => {
    try {
      const destinations = await storage.getAllDestinations();
      res.json(destinations);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching destinations' });
    }
  });

  // GET single destination
  app.get('/api/destinations/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const destination = await storage.getDestination(id);
      
      if (!destination) {
        return res.status(404).json({ message: 'Destination not found' });
      }
      
      res.json(destination);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching destination' });
    }
  });

  // GET destinations by country
  app.get('/api/destinations/country/:country', async (req: Request, res: Response) => {
    try {
      const country = req.params.country;
      const destinations = await storage.getDestinationsByCountry(country);
      res.json(destinations);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching destinations by country' });
    }
  });

  // GET all stories
  app.get('/api/stories', async (_req: Request, res: Response) => {
    try {
      const stories = await storage.getAllStories();
      res.json(stories);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching stories' });
    }
  });

  // GET single story
  app.get('/api/stories/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const story = await storage.getStory(id);
      
      if (!story) {
        return res.status(404).json({ message: 'Story not found' });
      }
      
      // Get user information
      const user = await storage.getUser(story.userId);
      
      res.json({
        ...story,
        user: user ? {
          id: user.id,
          username: user.username,
          fullName: user.fullName,
          profilePic: user.profilePic
        } : null
      });
    } catch (error) {
      res.status(500).json({ message: 'Error fetching story' });
    }
  });

  // GET stories by country
  app.get('/api/stories/country/:country', async (req: Request, res: Response) => {
    try {
      const country = req.params.country;
      const stories = await storage.getStoriesByCountry(country);
      res.json(stories);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching stories by country' });
    }
  });

  // GET stories by incident type
  app.get('/api/stories/type/:type', async (req: Request, res: Response) => {
    try {
      const type = req.params.type;
      const stories = await storage.getStoriesByIncidentType(type);
      res.json(stories);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching stories by type' });
    }
  });

  // POST create story
  app.post('/api/stories', async (req: Request, res: Response) => {
    try {
      const validatedData = insertStorySchema.parse(req.body);
      const story = await storage.createStory(validatedData);
      res.status(201).json(story);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid story data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error creating story' });
    }
  });

  // GET all chat rooms
  app.get('/api/chat-rooms', async (_req: Request, res: Response) => {
    try {
      const rooms = await storage.getAllChatRooms();
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching chat rooms' });
    }
  });

  // GET single chat room
  app.get('/api/chat-rooms/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const room = await storage.getChatRoom(id);
      
      if (!room) {
        return res.status(404).json({ message: 'Chat room not found' });
      }
      
      res.json(room);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching chat room' });
    }
  });

  // GET chat rooms by region
  app.get('/api/chat-rooms/region/:region', async (req: Request, res: Response) => {
    try {
      const region = req.params.region;
      const rooms = await storage.getChatRoomsByRegion(region);
      res.json(rooms);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching chat rooms by region' });
    }
  });

  // POST create chat room
  app.post('/api/chat-rooms', async (req: Request, res: Response) => {
    try {
      const validatedData = insertChatRoomSchema.parse(req.body);
      const room = await storage.createChatRoom(validatedData);
      res.status(201).json(room);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid chat room data', errors: error.errors });
      }
      res.status(500).json({ message: 'Error creating chat room' });
    }
  });

  // GET all messages for a chat room
  app.get('/api/chat-messages/:roomId', async (req: Request, res: Response) => {
    try {
      const roomId = parseInt(req.params.roomId);
      const messages = await storage.getChatMessagesByRoom(roomId);
      
      // Get user info for each message
      const enrichedMessages = await Promise.all(
        messages.map(async (message) => {
          const user = await storage.getUser(message.userId);
          return {
            ...message,
            username: user?.username || 'Unknown',
            userFullName: user?.fullName || 'Unknown',
            userProfilePic: user?.profilePic || ''
          };
        })
      );
      
      res.json(enrichedMessages);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching chat messages' });
    }
  });

  // GET safety alerts
  app.get('/api/safety-alerts', async (_req: Request, res: Response) => {
    try {
      const alerts = await storage.getAllSafetyAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching safety alerts' });
    }
  });

  // GET safety alerts by location
  app.get('/api/safety-alerts/location/:location', async (req: Request, res: Response) => {
    try {
      const location = req.params.location;
      const alerts = await storage.getSafetyAlertsByLocation(location);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching safety alerts by location' });
    }
  });

  // GET emergency services
  app.get('/api/emergency-services', async (_req: Request, res: Response) => {
    try {
      const services = await storage.getAllEmergencyServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching emergency services' });
    }
  });

  // GET emergency services by location
  app.get('/api/emergency-services/:country/:city?', async (req: Request, res: Response) => {
    try {
      const { country, city } = req.params;
      const services = await storage.getEmergencyServicesByLocation(country, city);
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching emergency services by location' });
    }
  });

  // POST SOS alert
  app.post('/api/sos', async (req: Request, res: Response) => {
    try {
      const { userId, latitude, longitude, contacts } = req.body;
      
      if (!userId || !latitude || !longitude) {
        return res.status(400).json({ message: 'Missing required fields' });
      }
      
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // In a real implementation, this would send notifications to emergency contacts
      // For now, just return a success response
      
      res.status(200).json({ 
        message: 'SOS alert sent successfully',
        timestamp: new Date().toISOString(),
        coordinates: { latitude, longitude },
        user: {
          id: user.id,
          fullName: user.fullName
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Error sending SOS alert' });
    }
  });

  // Safety score data endpoints

  // Safety score data endpoint
  app.get('/api/safety-scores', async (_req: Request, res: Response) => {
    try {
      const safetyData = getSafetyScoreData();
      res.status(200).json(safetyData);
    } catch (error) {
      console.error('Error fetching safety scores:', error);
      res.status(500).json({ message: 'Failed to retrieve safety score data' });
    }
  });
  
  // Get safety score for specific location
  app.get('/api/safety-scores/:lat/:lng', async (req: Request, res: Response) => {
    try {
      const lat = parseFloat(req.params.lat);
      const lng = parseFloat(req.params.lng);
      
      if (isNaN(lat) || isNaN(lng)) {
        return res.status(400).json({ message: 'Invalid coordinates provided' });
      }
      
      const safetyData = getSafetyScoreForLocation(lat, lng);
      
      if (!safetyData) {
        return res.status(404).json({ message: 'No safety data found for this location' });
      }
      
      res.status(200).json(safetyData);
    } catch (error) {
      console.error('Error fetching safety score for location:', error);
      res.status(500).json({ message: 'Failed to retrieve safety score data' });
    }
  });

  // Geofencing endpoint to check if user is within a specific radius of a location
  app.get('/api/geofencing/check', async (req: Request, res: Response) => {
    try {
      const { lat, lng, targetLat, targetLng, radius } = req.query;
      
      // Convert query parameters to numbers
      const userLat = parseFloat(lat as string);
      const userLng = parseFloat(lng as string);
      const locationLat = parseFloat(targetLat as string);
      const locationLng = parseFloat(targetLng as string);
      const safetyRadius = parseFloat(radius as string) || 20; // Default radius of 20km
      
      // Validate coordinates
      if (isNaN(userLat) || isNaN(userLng) || isNaN(locationLat) || isNaN(locationLng)) {
        return res.status(400).json({ 
          message: 'Invalid coordinates. All latitude and longitude values must be numbers.' 
        });
      }
      
      // Calculate distance between coordinates using Haversine formula
      const R = 6371; // Radius of the Earth in km
      const dLat = (locationLat - userLat) * (Math.PI/180);
      const dLon = (locationLng - userLng) * (Math.PI/180);
      
      const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(userLat * (Math.PI/180)) * Math.cos(locationLat * (Math.PI/180)) * 
        Math.sin(dLon/2) * Math.sin(dLon/2);
      
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const distance = R * c; // Distance in km
      
      // Check if within radius
      const isInside = distance <= safetyRadius;
      
      // Get safety score for the location
      const safetyData = getSafetyScoreForLocation(locationLat, locationLng);
      
      // Send response
      res.status(200).json({
        status: isInside ? 'inside' : 'outside',
        distance: Math.round(distance * 100) / 100, // Round to 2 decimal places
        message: isInside 
          ? `You are ${distance.toFixed(2)} km from the target location, within the safety zone.` 
          : `You are ${distance.toFixed(2)} km from the target location, outside the safety zone.`,
        safetyData
      });
    } catch (error) {
      console.error('Geofencing error:', error);
      res.status(500).json({ message: 'Failed to process geofencing check' });
    }
  });

  return httpServer;
}
