import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';

export interface SafetyScoreData {
  locationName: string;
  lat: number;
  long: number;
  safetyScore: number;
  lastIncidentDate: Date;
  mostCommonIssue: string;
  safeTime: string;
  riskTime: string;
  safetyStatus: string; // "Safe", "Moderate", "Unsafe"
}

export function getSafetyScoreData(): SafetyScoreData[] {
  try {
    const filePath = path.resolve('./attached_assets/Mock_Safety_Score_Data.csv');
    console.log('Looking for CSV at path:', filePath);
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    
    const records = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
    });
    
    return records.map((record: any) => {
      const safetyScore = parseInt(record['Safety Score'], 10);
      let safetyStatus = "Moderate";
      
      if (safetyScore >= 80) {
        safetyStatus = "Safe";
      } else if (safetyScore >= 50) {
        safetyStatus = "Moderate";
      } else {
        safetyStatus = "Unsafe";
      }
      
      return {
        locationName: record['Location Name'],
        lat: parseFloat(record['Lat']),
        long: parseFloat(record['Long']),
        safetyScore,
        lastIncidentDate: new Date(record['Last Incident Date']),
        mostCommonIssue: record['Most Common Issue'],
        safeTime: record['Safe Time'],
        riskTime: record['Risk Time'],
        safetyStatus
      };
    });
  } catch (error) {
    console.error('Error loading safety score data:', error);
    return [];
  }
}

// Get safety data for a specific location or closest match
export function getSafetyScoreForLocation(lat: number, lng: number): SafetyScoreData | null {
  const scores = getSafetyScoreData();
  if (scores.length === 0) return null;
  
  // Find the closest location by calculating distance using Haversine formula
  let closestLocation = scores[0];
  let minDistance = calculateDistance(lat, lng, closestLocation.lat, closestLocation.long);
  
  for (const location of scores) {
    const distance = calculateDistance(lat, lng, location.lat, location.long);
    if (distance < minDistance) {
      minDistance = distance;
      closestLocation = location;
    }
  }
  
  // Only return if reasonably close (within 10km)
  return minDistance <= 10 ? closestLocation : null;
}

// Calculate distance between two points using Haversine formula (in km)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}