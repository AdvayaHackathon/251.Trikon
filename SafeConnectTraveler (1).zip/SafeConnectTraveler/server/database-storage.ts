import { eq, like, and } from "drizzle-orm";
import { db } from "./db";
import { 
  users, type User, type InsertUser,
  destinations, type Destination, type InsertDestination,
  stories, type Story, type InsertStory,
  chatRooms, type ChatRoom, type InsertChatRoom,
  chatMessages, type ChatMessage, type InsertChatMessage,
  safetyAlerts, type SafetyAlert, type InsertSafetyAlert,
  emergencyServices, type EmergencyService, type InsertEmergencyService
} from "@shared/schema";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    // Ensure arrays are properly handled for JSON fields
    const preparedUser = {
      ...user,
      emergencyContacts: user.emergencyContacts ? JSON.stringify(user.emergencyContacts) : null
    };
    
    const [newUser] = await db.insert(users).values(preparedUser).returning();
    return newUser;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    // Handle JSON fields for arrays
    const preparedData = { ...data };
    if (data.emergencyContacts) {
      preparedData.emergencyContacts = JSON.stringify(data.emergencyContacts);
    }
    
    const [updatedUser] = await db
      .update(users)
      .set(preparedData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  // Destination methods
  async getDestination(id: number): Promise<Destination | undefined> {
    const [destination] = await db.select().from(destinations).where(eq(destinations.id, id));
    return destination;
  }

  async getAllDestinations(): Promise<Destination[]> {
    return await db.select().from(destinations);
  }

  async getDestinationsByCountry(country: string): Promise<Destination[]> {
    return await db
      .select()
      .from(destinations)
      .where(eq(destinations.country, country));
  }

  async createDestination(destination: InsertDestination): Promise<Destination> {
    const [newDestination] = await db
      .insert(destinations)
      .values(destination)
      .returning();
    return newDestination;
  }

  async updateDestination(id: number, data: Partial<InsertDestination>): Promise<Destination | undefined> {
    const [updatedDestination] = await db
      .update(destinations)
      .set(data)
      .where(eq(destinations.id, id))
      .returning();
    return updatedDestination;
  }
  
  // Story methods
  async getStory(id: number): Promise<Story | undefined> {
    const [story] = await db.select().from(stories).where(eq(stories.id, id));
    return story;
  }

  async getAllStories(): Promise<Story[]> {
    return await db.select().from(stories);
  }

  async getStoriesByCountry(country: string): Promise<Story[]> {
    return await db
      .select()
      .from(stories)
      .where(eq(stories.country, country));
  }

  async getStoriesByIncidentType(type: string): Promise<Story[]> {
    return await db
      .select()
      .from(stories)
      .where(eq(stories.incidentType, type));
  }

  async getStoriesByUser(userId: number): Promise<Story[]> {
    return await db
      .select()
      .from(stories)
      .where(eq(stories.userId, userId));
  }

  async createStory(story: InsertStory): Promise<Story> {
    // Handle JSON fields for arrays
    const preparedStory = {
      ...story,
      preventionTips: story.preventionTips ? JSON.stringify(story.preventionTips) : null
    };
    
    const [newStory] = await db
      .insert(stories)
      .values(preparedStory)
      .returning();
    return newStory;
  }

  async updateStory(id: number, data: Partial<InsertStory>): Promise<Story | undefined> {
    // Handle JSON fields for arrays
    const preparedData = { ...data };
    if (data.preventionTips) {
      preparedData.preventionTips = JSON.stringify(data.preventionTips);
    }
    
    const [updatedStory] = await db
      .update(stories)
      .set(preparedData)
      .where(eq(stories.id, id))
      .returning();
    return updatedStory;
  }
  
  // Chat Room methods
  async getChatRoom(id: number): Promise<ChatRoom | undefined> {
    const [room] = await db.select().from(chatRooms).where(eq(chatRooms.id, id));
    return room;
  }

  async getAllChatRooms(): Promise<ChatRoom[]> {
    return await db.select().from(chatRooms);
  }

  async getChatRoomsByRegion(region: string): Promise<ChatRoom[]> {
    return await db
      .select()
      .from(chatRooms)
      .where(eq(chatRooms.region, region));
  }

  async createChatRoom(room: InsertChatRoom): Promise<ChatRoom> {
    const [newRoom] = await db
      .insert(chatRooms)
      .values(room)
      .returning();
    return newRoom;
  }

  async updateChatRoom(id: number, data: Partial<InsertChatRoom>): Promise<ChatRoom | undefined> {
    const [updatedRoom] = await db
      .update(chatRooms)
      .set(data)
      .where(eq(chatRooms.id, id))
      .returning();
    return updatedRoom;
  }

  async updateChatRoomActiveUsers(id: number, count: number): Promise<void> {
    await db
      .update(chatRooms)
      .set({ activeUsers: count })
      .where(eq(chatRooms.id, id));
  }
  
  // Chat Message methods
  async getChatMessage(id: number): Promise<ChatMessage | undefined> {
    const [message] = await db.select().from(chatMessages).where(eq(chatMessages.id, id));
    return message;
  }

  async getChatMessagesByRoom(roomId: number): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.roomId, roomId));
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return newMessage;
  }
  
  // Safety Alert methods
  async getSafetyAlert(id: number): Promise<SafetyAlert | undefined> {
    const [alert] = await db.select().from(safetyAlerts).where(eq(safetyAlerts.id, id));
    return alert;
  }

  async getAllSafetyAlerts(): Promise<SafetyAlert[]> {
    return await db.select().from(safetyAlerts);
  }

  async getSafetyAlertsByLocation(location: string): Promise<SafetyAlert[]> {
    return await db
      .select()
      .from(safetyAlerts)
      .where(like(safetyAlerts.location, `%${location}%`));
  }

  async createSafetyAlert(alert: InsertSafetyAlert): Promise<SafetyAlert> {
    const [newAlert] = await db
      .insert(safetyAlerts)
      .values(alert)
      .returning();
    return newAlert;
  }
  
  // Emergency Service methods
  async getEmergencyService(id: number): Promise<EmergencyService | undefined> {
    const [service] = await db.select().from(emergencyServices).where(eq(emergencyServices.id, id));
    return service;
  }

  async getAllEmergencyServices(): Promise<EmergencyService[]> {
    return await db.select().from(emergencyServices);
  }

  async getEmergencyServicesByLocation(country: string, city?: string): Promise<EmergencyService[]> {
    if (city) {
      return await db
        .select()
        .from(emergencyServices)
        .where(
          and(
            eq(emergencyServices.country, country),
            eq(emergencyServices.city, city)
          )
        );
    } else {
      return await db
        .select()
        .from(emergencyServices)
        .where(eq(emergencyServices.country, country));
    }
  }

  async createEmergencyService(service: InsertEmergencyService): Promise<EmergencyService> {
    const [newService] = await db
      .insert(emergencyServices)
      .values(service)
      .returning();
    return newService;
  }
}