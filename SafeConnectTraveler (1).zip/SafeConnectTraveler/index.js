import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = 3000;

// Serve static files from the public directory
app.use(express.static(join(__dirname, 'public')));

// Geofencing endpoint
app.get('/check', (req, res) => {
  const { lat, lng } = req.query;
  
  // Convert to numbers
  const userLat = parseFloat(lat);
  const userLng = parseFloat(lng);
  
  // Hebbal, Bangalore coordinates
  const targetLat = 13.0352;
  const targetLng = 77.5970;
  
  // Check if coordinates are valid
  if (isNaN(userLat) || isNaN(userLng)) {
    return res.status(400).json({ 
      error: 'Invalid coordinates. Latitude and longitude must be numbers.' 
    });
  }
  
  // Calculate distance between coordinates
  const distance = calculateDistance(userLat, userLng, targetLat, targetLng);
  
  // Check if within 20km
  const isInside = distance <= 20;
  
  // Send response
  res.json({
    status: isInside ? 'inside' : 'outside',
    distance: Math.round(distance * 100) / 100, // Round to 2 decimal places
    message: isInside 
      ? `You are ${distance.toFixed(2)} km from Hebbal, within the safety zone.` 
      : `You are ${distance.toFixed(2)} km from Hebbal, outside the safety zone.`
  });
});

// Function to calculate distance between two points using Haversine formula (in km)
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Radius of the Earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c; // Distance in km
  
  return distance;
}

// Convert degrees to radians
function deg2rad(deg) {
  return deg * (Math.PI/180);
}

// Start the server
app.listen(port, '0.0.0.0', () => {
  console.log(`Geofencing app listening at http://localhost:${port}`);
});