import psList from 'ps-list';
import { exec } from 'child_process';

// Function to kill a process by PID
function killProcess(pid) {
  return new Promise((resolve, reject) => {
    exec(`kill -9 ${pid}`, (error) => {
      if (error) {
        console.error(`Error killing process ${pid}: ${error.message}`);
        reject(error);
      } else {
        console.log(`Successfully killed process with PID ${pid}`);
        resolve();
      }
    });
  });
}

// Get all processes and filter by command
async function main() {
  try {
    console.log('Looking for processes using port 5000...');
    
    // Get list of all processes
    const processes = await psList();
    
    // Filter potential Node.js processes that might be using port 5000
    // This is a rough estimate since we can't directly check port usage
    const nodeProcesses = processes.filter(proc => 
      (proc.cmd && proc.cmd.includes('node')) || 
      (proc.name && proc.name.includes('node'))
    );
    
    if (nodeProcesses.length === 0) {
      console.log('No Node.js processes found.');
      return;
    }
    
    console.log('Found the following Node.js processes:');
    nodeProcesses.forEach(proc => {
      console.log(`PID: ${proc.pid}, CMD: ${proc.cmd || proc.name}`);
    });
    
    // Attempt to kill Node.js processes and wait for completion
    console.log('Attempting to kill Node.js processes...');
    for (const proc of nodeProcesses) {
      try {
        await killProcess(proc.pid);
      } catch (error) {
        console.error(`Failed to kill process ${proc.pid}: ${error.message}`);
      }
    }
    
    console.log('Finished killing processes. You should now be able to start your server on port 5000.');
  } catch (error) {
    console.error('An error occurred:', error);
  }
}

main();