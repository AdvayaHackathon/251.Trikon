import { pgTable, text, serial, integer, boolean, timestamp, json, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  profilePic: text("profile_pic"),
  emergencyContacts: json("emergency_contacts").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Destination model
export const destinations = pgTable("destinations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull(),
  safetyScore: integer("safety_score").notNull(),
  safetyStatus: text("safety_status").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  activeTravelers: integer("active_travelers").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Theft Stories model
export const stories = pgTable("stories", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  incidentType: text("incident_type").notNull(),
  location: text("location").notNull(),
  country: text("country").notNull(),
  preventionTips: json("prevention_tips").$type<string[]>(),
  incidentDate: timestamp("incident_date").notNull(),
  userId: integer("user_id").notNull().references(() => users.id),
  likes: integer("likes").default(0).notNull(),
  comments: integer("comments").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Chat Rooms model
export const chatRooms = pgTable("chat_rooms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  region: text("region").notNull(),
  imageUrl: text("image_url"),
  activeUsers: integer("active_users").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Chat Messages model
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").notNull().references(() => chatRooms.id),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Safety Alerts model
export const safetyAlerts = pgTable("safety_alerts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  alertType: text("alert_type").notNull(),
  severity: text("severity").notNull(),
  location: text("location").notNull(),
  latitude: text("latitude"),
  longitude: text("longitude"),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Emergency Services model
export const emergencyServices = pgTable("emergency_services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serviceType: text("service_type").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  country: text("country").notNull(),
  city: text("city").notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  fullName: true,
  profilePic: true,
  emergencyContacts: true,
});

export const insertDestinationSchema = createInsertSchema(destinations).pick({
  name: true,
  country: true,
  safetyScore: true,
  safetyStatus: true,
  description: true,
  imageUrl: true,
  activeTravelers: true,
});

export const insertStorySchema = createInsertSchema(stories).pick({
  title: true,
  content: true,
  incidentType: true,
  location: true,
  country: true,
  preventionTips: true,
  incidentDate: true,
  userId: true,
});

export const insertChatRoomSchema = createInsertSchema(chatRooms).pick({
  name: true,
  description: true,
  location: true,
  region: true,
  imageUrl: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).pick({
  roomId: true,
  userId: true,
  content: true,
  imageUrl: true,
});

export const insertSafetyAlertSchema = createInsertSchema(safetyAlerts).pick({
  title: true,
  content: true,
  alertType: true,
  severity: true,
  location: true,
  latitude: true,
  longitude: true,
  expiresAt: true,
});

export const insertEmergencyServiceSchema = createInsertSchema(emergencyServices).pick({
  name: true,
  serviceType: true,
  phone: true,
  address: true,
  latitude: true,
  longitude: true,
  country: true,
  city: true,
});

// Relation definitions
export const usersRelations = relations(users, ({ many }) => ({
  stories: many(stories),
  chatMessages: many(chatMessages),
}));

export const storiesRelations = relations(stories, ({ one }) => ({
  user: one(users, {
    fields: [stories.userId],
    references: [users.id],
  }),
}));

export const chatRoomsRelations = relations(chatRooms, ({ many }) => ({
  messages: many(chatMessages),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  room: one(chatRooms, {
    fields: [chatMessages.roomId],
    references: [chatRooms.id],
  }),
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Destination = typeof destinations.$inferSelect;
export type InsertDestination = z.infer<typeof insertDestinationSchema>;

export type Story = typeof stories.$inferSelect;
export type InsertStory = z.infer<typeof insertStorySchema>;

export type ChatRoom = typeof chatRooms.$inferSelect;
export type InsertChatRoom = z.infer<typeof insertChatRoomSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type SafetyAlert = typeof safetyAlerts.$inferSelect;
export type InsertSafetyAlert = z.infer<typeof insertSafetyAlertSchema>;

export type EmergencyService = typeof emergencyServices.$inferSelect;
export type InsertEmergencyService = z.infer<typeof insertEmergencyServiceSchema>;
